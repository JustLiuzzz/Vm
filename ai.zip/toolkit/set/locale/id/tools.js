let infos = Data.infos.tools ??= {};


/*!-======[ Enhance Info ]======-!*/
infos.enhance = `
*SILAHKAN PILIH TYPE YANG TERSEDIA!*
▪︎ Photo style
- phox2 
- phox4
▪︎ Anime style
- anix2
- anix4
▪︎ Standard
- stdx2
- stdx4
▪︎ Face Enhance
- cf
▪︎ Object text
- text

_Cara penggunaan: #enhance phox4_
`
