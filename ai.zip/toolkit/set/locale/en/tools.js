let infos = Data.infos.tools ??= {};


/*!-======[ Enhance Info ]======-!*/
infos.enhance = `
*PLEASE CHOOSE THE AVAILABLE TYPE! *
▪︎ Photo style
- phox2 
- phox4
▪︎ Anime style
- anix2
- anix4
▪︎ Standard
- stdx2
- stdx4
▪︎ Face Enhance
- cf
▪︎ Object text
- text

_How to use: #enhance phox4_
`
