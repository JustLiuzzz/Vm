const {
    green,
    greenBright,
    cyanBright,
    redBright
} = require('chalk');
const fs = require('fs'),
    path = require('path'),
    moment = require('moment-timezone'),
    func = require('./functions.js');
moment.tz.setDefault('Asia/Jakarta').locale('id');

function sanitizeFileName(fileName) {
    // Karakter yang tidak diperbolehkan dalam nama file
    const invalidChars = /[\/\\:*?"<>|]/g;

    // Menghapus karakter yang tidak valid
    let sanitizedFileName = fileName.replace(invalidChars, '');

    // Menghapus whitespace di awal dan akhir
    sanitizedFileName = sanitizedFileName.trim();

    return sanitizedFileName;
}

module.exports = async (kuromi, m, msg = false) => {
    let isMSG = true;
    let who = m.fromMe ? 'Bot' : m.pushname || 'Tanpa nama';
    let time = m.messageTimestamp;
    if (!m.budy) return (m.mtype ? console.log('\n' + greenBright.bold('[ TYPE ]'), m.mtype) : null)
  
    if (m.isGc && typeof global.db.groups[m.chat] !== 'undefined' && !global.db.groups[m.chat].mute) {
        const groups = global.db.groups[m.chat];
        const metadata = global.db.metadata[m.chat];
        const subject = metadata?.subject || 'anonymous';
        const ephemeralDuration = metadata?.ephemeralDuration || 0;
        if (groups.name != subject) groups.name = subject;
        if (groups.expiration != ephemeralDuration) groups.expiration = ephemeralDuration;
        let groupName = cyanBright.bold(subject);
        if (m.isPrefix) return console.log('\n' + greenBright.bold('[ CMD ]'), moment(time * 1000).format('DD/MM/YY HH:mm:ss'), green.bold('from'), func.color('[' + m.sender.split('@')[0] + '] ', 'orange') + cyanBright.bold(who), green.bold('in'), func.color('[' + m.chat + '] ', 'orange') + groupName, `\n${m.budy}`)
        if (isMSG) console.log('\n' + greenBright.bold('[ MSG ]'), moment(time * 1000).format('DD/MM/YY HH:mm:ss'), green.bold('from'), func.color('[' + m.sender.split('@')[0] + '] ', 'orange') + cyanBright.bold(who), green.bold('in'), func.color('[' + m.chat + '] ', 'orange') + groupName, `\n${m.budy}`)
        /*let chat = fs.createWriteStream(path.join(process.cwd(), `database/groups/${sanitizeFileName(subject)}.txt`), {
            flags: 'a'
        })
        let times = moment(time * 1000).format('DD/MM/YY HH:mm:ss');
        let users = global.db.users[m.sender];
        if (/(document|audio|sticker|webp|image|video)/.test(m.mime) || !m.budy) chat.write(`[${times}] ${m.pushname || users.name}: <${m.mtype}>\n`)
        else chat.write(`[${times}] ${m.pushname || users.name}: ${m.budy}\n`)*/
    } else if (m.isPc) {
        if (m.setting.online) {
            await kuromi.sendPresenceUpdate('available', m.chat);
            await kuromi.readMessages([m.key]);
        } else {
            await kuromi.sendPresenceUpdate('unavailable', m.chat);
        }
        if (m.isPrefix) return console.log('\n' + greenBright.bold('[ CMD ]'), moment(time * 1000).format('DD/MM/YY HH:mm:ss'), green.bold('from'), func.color('[' + m.sender.split('@')[0] + '] ', 'orange') + cyanBright.bold(who), green.bold('in'), func.color('[' + m.chat + ']', 'orange'), `\n${m.budy}`)
        if (isMSG) console.log('\n' + greenBright.bold('[ MSG ]'), moment(time * 1000).format('DD/MM/YY HH:mm:ss'), green.bold('from'), '[' + m.sender.split('@')[0] + '] ' + cyanBright.bold(who), func.color('<' + m.mtype + '>', 'orange'), `\n${m.budy}`)
    }
}

func.reloadFile(__filename)