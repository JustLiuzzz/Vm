//CREATE BY REZA DEVS KUROMI
exports.run={usage:["unblockall"],category:"owner",async:async(a,{kuromi:l})=>{var e,o=await l.fetchBlocklist().catch(a=>[]);if(0===o.length)return a.reply("Tidak ada nomor yang diblokir.");let t=0,n=0;for(e of o)await l.updateBlockStatus(e,"unblock").then(()=>t++).catch(()=>n++);a.reply(`*Unblock All Selesai*

`+`✅ Berhasil: *${t}*
`+`❌ Gagal: *${n}*

`+`Total: *${o.length}* nomor.`)},owner:!0};