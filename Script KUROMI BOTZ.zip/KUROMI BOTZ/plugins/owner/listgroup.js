//CREATE BY REZA DEVS KUROMI
let database={},success=0,failed=0;exports.run={usage:["listgroup"],hidden:["listgrup","listgc"],category:"owner",async:async(t,{func:e,kuromi:i})=>{var a=Object.values(await i.groupFetchAllParticipating().catch(a=>[]));if(0==a.length)return t.reply("Tidak ada grup yang ditemukan.");let r=`乂  *L I S T - G R U P*

Terdapat total *${a.length}* grup.

`;a.forEach((a,e)=>{r+=""+(e+1)+`. ${a.subject}
- ID: ${a.id}
- Total peserta: ${a.participants?Object.keys(a.participants).length:"0"}

`}),r=(r=(r=(r=(r=(r=(r=(r=(r=(r=(r=(r=r+`*Pilihan Opsi:*
_${t.cmd} [nomor] [opsi]_`+`

*Contoh Penggunaan:*`)+`
- \`${t.cmd} 1 id\` - menampilkan id grup.`)+`
- \`${t.cmd} 1 detail\` - menampilkan detail grup.`)+`
- \`${t.cmd} 1 profile\` - menampilkan profil grup.`)+`
- \`${t.cmd} 1 desc\` - menampilkan deskripsi grup.`)+`
- \`${t.cmd} 1 link\` - menampilkan tautan grup.`)+`
- \`${t.cmd} 1 leave\` - mengeluarkan bot dari grup.`)+`
- \`${t.cmd} 1 close\` - menutup grup.`)+`
- \`${t.cmd} 1 open\` - membuka grup.`)+`
- \`${t.cmd} 1 admin\` - menampilkan daftar admin.`)+`
- \`${t.cmd} 1 member\` - menampilkan daftar anggota.`)+`
- \`${t.cmd} 1 kickall\` - mengeluarkan semua anggota.`;var[n,p]=t.args;if(!n||!p)return t.reply(r);let s=a[parseInt(n)-1];if(!s)return t.reply("Nomor grup tidak valid.");var c=s.id;switch(p.toLowerCase()){case"id":i.reply(t.chat,c,t,{expiration:t.expiration});break;case"detail":{var l=await i.groupMetadata(c).catch(()=>{}),u=e.findAdmin(l.participants).includes(t.bot);let a="◦  Nama Grup: "+l.subject;a=(a=(a=(a=(a+=`
◦  ID Grup: `+l.id)+`
◦  Total Member: `+l.size)+`
◦  Edit Setelan Grup: `+(l.restrict?"Hanya admin":"Semua peserta"))+`
◦  Kirim Pesan: `+(l.announce?"Hanya admin":"Semua peserta")+`
◦  Bot Admin: `+(u?"Ya":"Tidak"))+`
◦  Pesan Sementara: `+(l.ephemeralDuration?"Aktif":"Mati"),l.hasOwnProperty("isCommunity")&&(a+=`
◦  isCommunity: `+(l.isCommunity?"Ya":"Tidak")),l.hasOwnProperty("isCommunityAnnounce")&&(a+=`
◦  isCommunityAnnounce: `+(l.isCommunityAnnounce?"Ya":"Tidak")),l.hasOwnProperty("joinApprovalMode")&&(a+=`
◦  Setujui Anggota Baru: `+(l.joinApprovalMode?"Ya":"Tidak")),l.hasOwnProperty("memberAddMode")&&(a+=`
◦  Tambah anggota lain: `+(l.memberAddMode?"Ya":"Tidak")),i.reply(t.chat,a,t,{expiration:t.expiration});break}case"profile":i.sendReact(t.chat,"🕒",t.key),u=await e.getBuffer(await i.profilePictureUrl(c,"image").catch(a=>"https://files.catbox.moe/ifx2y7.png")),i.sendMessage(t.chat,{image:u},{quoted:t,ephemeralExpiration:t.expiration});break;case"desc":l=await i.groupMetadata(c).catch(a=>{}),i.reply(t.chat,l.desc,t,{expiration:t.expiration});break;case"link":if(!(u=await i.groupInviteCode(c).catch(a=>"")))return t.reply(global.mess.botAdmin);l=`Link Group ${(await i.groupMetadata(c).catch(a=>{})).subject}

https://chat.whatsapp.com/`+u,i.reply(t.chat,l,t,{expiration:t.expiration});break;case"leave":await i.reply(c,"Saya diperintahkan untuk keluar dari grup ini. Terima kasih dan maaf atas kesalahan selama di sini."),await i.groupLeave(c).then(()=>t.reply(`Berhasil keluar dari grup "${s.subject}".`)).catch(()=>t.reply(`Gagal keluar dari grup "${s.subject}".`));break;case"close":await i.groupSettingUpdate(c,"announcement").then(()=>t.reply(`Grup "${s.subject}" berhasil ditutup.`)).catch(()=>t.reply(`Gagal menutup grup "${s.subject}".`));break;case"open":await i.groupSettingUpdate(c,"not_announcement").then(()=>t.reply(`Grup "${s.subject}" berhasil dibuka.`)).catch(()=>t.reply(`Gagal membuka grup "${s.subject}".`));break;case"admin":l=(u=await i.groupMetadata(c).catch(()=>{})).participants.filter(a=>a.admin).map((a,e)=>e+1+". @"+a.id.split("@")[0]).join("\n"),u=`*Daftar Admin Grup "${u.subject}"*

`+l,i.reply(t.chat,u,t,{expiration:t.expiration});break;case"member":u=(l=await i.groupMetadata(c).catch(()=>{})).participants.map((a,e)=>`${e+1}. @${a.id.split("@")[0]} (${"superadmin"===a.admin?"Owner":"admin"===a.admin?"Admin":"Member"})`).join("\n"),l=`*Daftar Member Grup "${l.subject}"*

`+u,i.reply(t.chat,l,t,{expiration:t.expiration});break;case"kickall":{if(0==(l=(u=await i.groupMetadata(c).catch(()=>{})).participants.filter(a=>null==a.admin).map(a=>a.id)).length)return t.reply("Data empty.");let a=`Are you sure you want to kick all participants group "${u.subject}" ?
Timeout *60* detik.

ketik *(Y/N)*`.trim(),e=(await i.reply(t.chat,a,t,{expiration:t.expiration})).key;database[t.sender]={jid:t.sender,groupId:c,groupName:u.subject||"-",key:t.key,members:l,timeout:setTimeout(()=>{t.reply("Timeout."),i.sendMessage(t.chat,{delete:e}),delete database[t.sender]},6e4)};break}default:i.reply(t.chat,`Opsi "${p}" tidak valid. Pilihan Opsi: detail, profile, desc, link, leave, close, open, admin, member, kickall.`,t,{expiration:t.expiration})}},main:async(a,{kuromi:e})=>{if(!a.isBot&&a.sender in database&&a.budy){var{jid:t,groupId:i,groupName:r,key:n,members:p,timeout:s}=database[a.sender];if(a.id!==n.id){if(/^(n|no)$/i.test(a.budy))return clearTimeout(s),delete database[t],a.reply(`Kick all in group "${r}" successfully cancelled.`);if(/^(y|yes)$/i.test(a.budy))try{clearTimeout(s),a.reply(`Wait is kicking ${p.length} participants...`);for(var c of p)try{await e.groupParticipantsUpdate(i,[c],"remove"),success++,await new Promise(a=>setTimeout(a,1e3))}catch(e){console.log(e),failed++}delete database[t],a.reply(`Succes kick all *${0<failed?success:success+failed}* participants in group "${r}".
- Success: ${success}
- Failed: `+failed),success=0,failed=0}catch(e){console.log(e),a.reply("Failed to kick all participants.")}}}},owner:!0,location:"plugins/owner/listgroup.js"};