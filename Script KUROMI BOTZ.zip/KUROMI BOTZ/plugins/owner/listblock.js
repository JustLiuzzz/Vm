//CREATE BY REZA DEVS KUROMI
exports.run={usage:["listblock"],category:"owner",async:async(a,{kuromi:e,setting:t})=>{var r=await e.fetchBlocklist().catch(a=>[]);if(0==r.length)return a.reply("Empty data.");var l="乂  *L I S T - B L O C K*\n\n",l=(l+=`Total: *${r.length}* blocked

`)+r.map((a,e)=>e+1+". @"+a.replace(/@.+/,"")).join("\n");await(t.fakereply?e.sendMessageModify(a.chat,l,a,{title:global.header,body:global.footer,thumbnail:await(await fetch(t.cover)).buffer(),largeThumb:!0,expiration:a.expiration}):a.reply(l))},owner:!0};