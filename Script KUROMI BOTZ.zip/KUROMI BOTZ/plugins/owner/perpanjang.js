//CREATE BY REZA DEVS KUROMI
let toMs=require("ms"),listharga=`乂  *P A K E T - P R E M I U M*

PAKET *P1*
- Masa aktif 7 hari
- Unlimited limit
- 1000.000 balance
PAKET *P2*
- Masa aktif 15 hari
- Unlimited limit
- 10.000.000 balance
PAKET *P3*
- Masa aktif 30 hari
- Unlimited limit
- 100.000.000 balance
PAKET *P4*
- Masa aktif 60 hari
- Unlimited limit
- 500.000.000 balance

乂  *P A K E T - S E W A B O T*

PAKET *S1*
- 15 day / Group
PAKET *S2*
- 30 day / Group
PAKET *S3*
- 60 day / Group
PAKET *S4*
- 90 day / Group`;exports.run={usage:["perpanjang"],use:"[type] [jid] [paket]",category:"owner",async:async(e,{func:a,kuromi:r})=>{var i,[p,t,n]=e.text.split(",");if(!e.text)return e.reply(`Contoh pengguna:
${e.cmd} [type], [jid], [paket]

Contoh perpanjang premium:
${e.prefix+e.command} premium, +62xxx, P1/P2/P3/P4

Contoh perpanjang sewabot:
${e.prefix+e.command} sewabot, 120@g.us, S1/S2/S3/S4`);if(!p)return e.reply("Input type perpanjang: *premium* atau *sewabot*");if(!t)return e.reply("Input jid perpanjang: *+62xxx* atau *120@g.us*");if(!n)return e.reply(`Input paket perpanjang!

`+listharga);if(e.text&&a.somematch(["prem","premium"],p)){var l=t.replace(/[^0-9]/g,"")+"@s.whatsapp.net",m=global.db.users[l];if(void 0===m)return e.reply("User data not found.");if(!m.premium)return e.reply(`@${l.replace(/@.+/,"")} bukan pengguna premium.`);if("P1"==n.trim())m.limit+=99999,m.balance+=1e6,m.expired.premium+=toMs("7d"),e.reply(`Berhasil perpanjang premium @${l.replace(/@.+/,"")} selama 7 hari.`);else if("P2"==n.trim())m.limit+=99999,m.balance+=1e7,m.expired.premium+=toMs("15d"),e.reply(`Berhasil perpanjang premium @${l.replace(/@.+/,"")} selama 15 hari.`);else if("P3"==n.trim())m.limit+=99999,m.balance+=1e8,m.expired.premium+=toMs("30d"),e.reply(`Berhasil perpanjang premium @${l.replace(/@.+/,"")} selama 30 hari.`);else{if("P4"!=n.trim())return e.reply("Invalid format.");m.limit+=99999,m.balance+=5e8,m.expired.premium+=toMs("90d"),e.reply(`Berhasil perpanjang premium @${l.replace(/@.+/,"")} selama 90 hari.`)}}else if(e.text&&a.somematch(["sewa","sewabot"],p)){if(void 0===(p=t.trim().includes("chat.whatsapp.com")&&(m=/chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i,[i,l]=t.trim().match(m)||[],l)?(a=await r.groupQueryInvite(l),global.db.groups[a.id]):global.db.groups[t.trim()]))return e.reply("Group data not found.");if(!p.sewa.status)return e.reply("Group tersebut tidak terdaftar di list sewabot.");if("S1"==n.trim())p.sewa.expired+=toMs("15d"),e.reply(`Berhasil perpanjang sewa ${p.name} selama 15 hari.`);else if("S2"==n.trim())p.sewa.expired+=toMs("30d"),e.reply(`Berhasil perpanjang sewa ${p.name} selama 30 hari.`);else if("S3"==n.trim())p.sewa.expired+=toMs("60d"),e.reply(`Berhasil perpanjang sewa ${p.name} selama 60 hari.`);else{if("S4"!=n.trim())return e.reply("Invalid format.");p.sewa.expired+=toMs("150d"),e.reply(`Berhasil perpanjang sewa ${p.name} selama 150 hari.`)}}},owner:!0};