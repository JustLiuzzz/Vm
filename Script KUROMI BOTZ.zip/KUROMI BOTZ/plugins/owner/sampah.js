//CREATE BY REZA DEVS KUROMI
let fs=require("fs"),path=require("path");exports.run={usage:["sampah","delsampah"],category:"owner",async:async(i,{func:n,kuromi:p})=>{switch(i.command){case"sampah":var a=fs.readdirSync("./sampah").filter(e=>["gif","png","mp3","m4a","opus","mp4","jpg","jpeg","webp","webm","bin"].some(a=>e.endsWith(a)));if(0==a.length)return i.reply("Empty trash.");var e=`乂  JUMLAH SAMPAH SYSTEM

`,e=(e+=`Total : ${a.length} Sampah

`)+a.map(a=>a).join("\n");p.reply(i.chat,e,i,{expiration:i.expiration});break;case"delsampah":a=path.join("./sampah"),fs.readdir(a,async function(a,e){if(a)return i.reply("Unable to scan directory: "+a);let t=`Detected ${(a=await e.filter(e=>["gif","png","mp3","m4a","opus","mp4","jpg","jpeg","webp","webm","bin"].some(a=>e.endsWith(a)))).length} junk file
`;if(0==a.length)return i.reply(t);a.map(function(a,e){t+=`
${e+1}. `+a}),e=(await p.reply(i.chat,t,i,{expiration:i.expiration})).key,await n.delay(2e3),await p.reply(i.chat,"Delete junk files...",i,{edit:e,expiration:i.expiration}),await a.forEach(function(a){fs.unlinkSync("./sampah/"+a)}),await n.delay(2e3),await p.reply(i.chat,"Successfully removed all trash",i,{edit:e,expiration:i.expiration})})}},owner:!0,location:"plugins/owner/sampah.js"};