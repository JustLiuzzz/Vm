//CREATE BY REZA DEVS KUROMI
let moment=require("moment-timezone");exports.run={usage:["nowa"],use:"number wa",category:"owner",async:async(t,{func:a,kuromi:e})=>{if(!t.text)return t.reply(a.example(t.cmd,"6285700408187x"));if(!t.text.includes("x"))return t.reply(`Masukkan tanda x di belakang nomor.
Contoh: ${t.prefix+t.command} 6285700408187x`);function n(t,a){return t.split(a).length-1}t.reply(global.mess.wait);var r,o=t.text.split("x")[0],s=t.text.split("x")[n(t.text,"x")]?t.text.split("x")[n(t.text,"x")]:"",l=(1==(a=n(t.text,"x"))?r=10:2==a?r=100:3==a&&(r=1e3),"LIST NOMOR WHATSAPP\n\nPunya Bio/status/info"),i="\n\nTanpa Bio/status/info",m="\n\nTidak Terdaftar";for(let t=0;t<r;t++){var h=["1","2","3","4","5","6","7","8","9"];Math.floor(Math.random()*h.length),Math.floor(Math.random()*h.length),Math.floor(Math.random()*h.length),Math.floor(Math.random()*h.length),(h=await e.onWhatsApp(""+o+t+s+"@s.whatsapp.net")).length;try{try{var x=await e.fetchStatus(h[0].jid)}catch{x="401"}"401"==x||0==x.status.length?i+=`
wa.me/`+h[0].jid.split("@")[0]:l+=`
wa.me/${h[0].jid.split("@")[0]}
Biography : ${x.status}
Date : `+moment(x.setAt).tz("Asia/Jakarta").format("HH:mm:ss DD/MM/YYYY")}catch{m+=`
`+o+t+s}}t.reply(""+l+i+m)},owner:!0};