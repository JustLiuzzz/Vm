//CREATE BY REZA DEVS KUROMI
let fs=require("fs"),path=require("path");exports.run={usage:["ceksession"],hidden:["ceksesi"],category:"special",async:async(e,{func:s,kuromi:i})=>{let n="session",a=fs.readdirSync(n),t=0;a.map(e=>t+=fs.statSync(path.join(n,e)).size);var o=`Session Information

- Total Session : ${a.length} Files
- Size Session : `+t.sizeString();i.reply(e.chat,s.texted("monospace",o),e)}};