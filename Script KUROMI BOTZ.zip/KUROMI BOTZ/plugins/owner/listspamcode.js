//CREATE BY REZA DEVS KUROMI
exports.run={usage:["listspamkode"],hidden:["listspamcode"],category:"owner",async:async(a,{func:s})=>{var e=global.db.spamcode.filter(a=>a.status);if(0==e.length)return a.reply("Empty data.");let t="乂  *L I S T  S P A M  C O D E*";e.forEach((a,e)=>{t=(t=(t=(t+=`

${e+1}. @`+a.number.split("@")[0])+`
◦  Status: `+(a.status?"✅":"❌"))+`
◦  Success : `+s.toRupiah(a.success))+`
◦  Failed : `+s.toRupiah(a.failed)}),await a.reply(t)},owner:!0};