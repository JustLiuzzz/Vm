//CREATE BY REZA DEVS KUROMI
exports.run={main:async(a,{func:e,kuromi:n,groups:t})=>{var o;for(o of[...new Set([...a.mentionedJid||[],...a.quoted?[a.quoted.sender]:[]])]){var d,r=global.db.users[o];!r||!(d=r.afk)||d<0||(r=r.alasan||"",a.fromMe)||10<=a.mentionedJid?.length||t.mute||"setalasan"===a.command||n.reply(a.chat,`Jangan tag dia!
Dia sedang AFK ${r?"dengan alasan "+r:""}
Selama *${e.clockString(new Date-d)}*`,a).then(async()=>{})}},group:!0};