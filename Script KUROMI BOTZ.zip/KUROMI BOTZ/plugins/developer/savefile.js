let path = require("path"), fs = require("fs");
exports.run = {
  usage: ["savefile"],
  hidden: ["sf"],
  use: "path file",
  category: "owner",
  async: async (e, { func: a, kuromi: t, quoted: s }) => {
    if (!e.text) return e.reply(a.example(e.cmd, "config.js"));
    if (!e.quoted) return e.reply("Mau simpan plugin dengan command apa? reply teks script nya!");
    try {
      var i = e.text.trim().toLowerCase(),
        n = path.join(process.cwd(), i),
        r = /application\/javascript/.test(s.mime) ? await s.download() : e.quoted.text;
      fs.writeFileSync(n, r);
      await t.sendReact(e.chat, "✅", e.key);
    } catch (a) {
      console.log(a);
      t.sendReact(e.chat, "❌", e.key);
    }
  },
  devs: !0,
  location: "plugins/developer/savefile.js"
};