exports.run = {
  usage: ['reactch'], // Command utama
  hidden: [], // Command simpel
  use: 'Masukkan link channel WhatsApp dengan format yang benar.', // Deskripsi
  category: 'tools',
  async: async (m, { func, kuromi, isOwner }) => {
    if (!m.text) return m.reply("Masukkan link channel WhatsApp dengan format yang benar.");

    const match = m.text.match(/https:\/\/whatsapp\.com\/channel\/(\w+)(?:\/(\d+))?/);
    if (!match) return m.reply("URL tidak valid. Silakan periksa kembali.");

    const channelId = match[1];
    const chatId = match[2];
    if (!chatId) return m.reply("ID chat tidak ditemukan dalam link yang diberikan.");

    try {
      const data = await kuromi.newsletterMetadata("invite", channelId);
      if (!data) return m.reply("Newsletter tidak ditemukan atau terjadi kesalahan.");

      await kuromi.newsletterReactMessage(data.id, chatId, m.text.split(" ").slice(1).join(" ") || "😋");
      m.reply("✅ Reaksi berhasil dikirim!");
    } catch (error) {
      m.reply("❌ Terjadi kesalahan: " + error.message);
    }
  },
  devs: true
};