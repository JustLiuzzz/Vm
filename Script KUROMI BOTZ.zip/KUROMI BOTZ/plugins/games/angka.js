exports.run = {
  usage: ['angka'],
  hidden: [],
  use: 'Game tebak angka 0-9 melawan bot',
  category: 'games',
  async: async (m, { func, kuromi, args, text }) => {
    let bonus = `${Math.floor(Math.random() * 1000)}`.trim();

    if (!m.text) return m.reply(`• *Example :* .angka 1/9`)

    if (['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'].includes(m.text)) {
      let angkaBot = pickRandom(['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']);

      let message = `
*「 TEBAK ANGKA 」*

Angka Kamu : ${m.text}
Angka Bot : ${angkaBot}

Apakah Angkamu Dengan Bot Sama?

+${bonus} XP!
      `.trim();

      await kuromi.sendMessage(m.chat, { text: message }, { quoted: m });
    } else {
      kuromi.sendMessage(m.chat, { text: `Pilih Angka 0 sampai 9!` }, { quoted: m });
    }
  }
};

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}