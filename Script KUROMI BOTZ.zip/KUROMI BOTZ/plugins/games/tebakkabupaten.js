//CREATE BY REZA DEVS KUROMI
let fetch = require("node-fetch"),
similarity = require("similarity"),
sensitive = 0.75,
database = {},
player = 0;

exports.run = {
  usage: ["tebakkabupaten"],
  hidden: ["tkab"],
  category: "games",
  async: async (a, { func: e, kuromi: t, setting: s }) => {
    if (e.ceklimit(a.sender, 1)) return a.reply(global.mess.limit);
    if (a.chat in database) return t.reply(a.chat, "Masih ada soal belum terjawab di chat ini", database[a.chat].chat);

    let res = await fetch("https://api.siputzx.my.id/api/games/kabupaten");
    let json = await res.json();
    let img = json.url;
    let answer = json.title;
    let reward = e.hadiah(s.hadiah);
    let time = Date.now();

    let caption = `G A M E - T E B A K  K A B U P A T E N

Tebak nama kabupaten berdasarkan logo berikut!

Hadiah: $${reward} balance
Waktu: ${s.gamewaktu} detik`;

    player = 0;
    database[a.chat] = {
      id: time,
      chat: await t.sendMessage(a.chat, {
        image: { url: img },
        caption: caption
      }, { quoted: a }),
      soal: img,
      jawaban: answer.toLowerCase(),
      hadiah: reward,
      salah: 0,
      waktu: setTimeout(() => {
        if (database[a.chat]?.id == time) {
          t.sendMessage(a.chat, {
            text: `Waktu habis!\n\nJawabannya adalah: ${e.texted("monospace", answer)}`
          }, { quoted: database[a.chat].chat });
          delete database[a.chat];
        }
      }, 1e3 * s.gamewaktu)
    };
  },

  main: async (n, { func: d, kuromi: r, setting: h }) => {
    if (n.chat in database && !n.fromMe && !n.isPrefix) {
      let db = database[n.chat];
      if (similarity(db.jawaban, n.budy.toLowerCase()) >= sensitive) {
        player++;
        r.sendMessage(n.chat, { react: { text: "✅", key: n.key } });
        global.db.users[n.sender].balance += db.hadiah;
        global.db.users[n.sender].game.tebakkabupaten = (global.db.users[n.sender].game.tebakkabupaten || 0) + 1;
        clearTimeout(db.waktu);
        delete database[n.chat];
        setTimeout(async () => {
          if (player > 1) return;
          if (global.db.users[n.sender].limit < 1) return n.reply("Soal dihentikan karena limit kamu sudah habis.");
          --global.db.users[n.sender].limit;

          let res = await fetch("https://api.siputzx.my.id/api/games/kabupaten");
          let json = await res.json();
          let img = json.url;
          let answer = json.title;
          let reward = d.hadiah(h.hadiah);
          let time = Date.now();

          let caption = `LANJUT SOAL BERIKUTNYA

Tebak nama kabupaten berdasarkan logo berikut!

Hadiah: $${reward} balance
Waktu: ${h.gamewaktu} detik`;

          player = 0;
          database[n.chat] = {
            id: time,
            chat: await r.sendMessage(n.chat, {
              image: { url: img },
              caption: caption
            }, { quoted: n }),
            soal: img,
            jawaban: answer.toLowerCase(),
            hadiah: reward,
            salah: 0,
            waktu: setTimeout(() => {
              if (database[n.chat]?.id == time) {
                r.sendMessage(n.chat, {
                  text: `Waktu habis!\n\nJawabannya adalah: ${d.texted("monospace", answer)}`
                }, { quoted: database[n.chat].chat });
                delete database[n.chat];
              }
            }, 1e3 * h.gamewaktu)
          };
        }, 1e3);
      } else {
        db.salah++;
        await r.sendMessage(n.chat, { react: { text: "❌", key: n.key } });
        if (db.salah >= 3) {
          clearTimeout(db.waktu);
          r.sendMessage(n.chat, {
            text: `Kesempatan habis setelah 3 jawaban salah!\n\nJawabannya adalah: ${d.texted("monospace", db.jawaban)}`
          }, { quoted: db.chat });
          delete database[n.chat];
        }
      }
    }
  }
};