//CREATE BY REZA DEVS KUROMI
let similarity=require("similarity"),gamesUrl="https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/tebaklogo.json",sensitive=.75,database={},player=0;exports.run={usage:["tebaklogo"],hidden:["tlogo"],category:"games",async:async(a,{func:e,kuromi:t,setting:i,users:s})=>{if(e.ceklimit(a.sender,1))return a.reply(global.mess.limit);if(a.chat in database)return t.reply(a.chat,"Masih ada soal belum terjawab di chat ini",database[a.chat].chat);let{name:n,image:r}=(await fetch(gamesUrl).then(a=>a.json())).result.random(),d=e.hadiah(i.hadiah),o=Date.now();s=`*G A M E - T E B A K L O G O*

Logo game apakah diatas?${s.premium?"\nPetunjuk: "+e.texted("monospace",n.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi,"-")):""}
Hadiah: $${d} balance
Waktu: ${i.gamewaktu} detik`,player=0,database[a.chat]={id:o,chat:await t.sendMessage(a.chat,{image:{url:r},caption:s},{quoted:a,ephemeralExpiration:a.expiration}),jawaban:n.toLowerCase(),hadiah:d,waktu:setTimeout(function(){database[a.chat].id==o&&(t.reply(a.chat,`Waktu habis!

Jawabannya adalah: `+e.texted("monospace",n),database[a.chat].chat,{expiration:a.expiration}),delete database[a.chat])},1e3*i.gamewaktu)}},main:async(n,{func:r,kuromi:d,setting:o,users:h})=>{var a,e,t,i;n.chat in database&&!n.fromMe&&!n.isPrefix&&({soal:a,jawaban:e,hadiah:t,waktu:i}=database[n.chat],similarity(e,n.budy.toLowerCase())>=sensitive?(player++,await d.sendReact(n.chat,"✅",n.key),global.db.users[n.sender].balance+=t,global.db.users[n.sender].game.tebaklogo+=1,clearTimeout(i),delete database[n.chat],setTimeout(async()=>{if(!(1<player)){if(global.db.users[n.sender].limit<1)return n.reply("Soal dihentikan karena limit kamu sudah habis.");--global.db.users[n.sender].limit;let{name:a,image:e}=(await fetch(gamesUrl).then(a=>a.json())).result.random(),t=r.hadiah(o.hadiah),i=Date.now(),s=`*LANJUT SOAL BERIKUTNYA*

Logo game apakah diatas?${h.premium?"\nPetunjuk: "+r.texted("monospace",a.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi,"-")):""}
Hadiah: $${t} balance
Waktu: ${o.gamewaktu} detik`;player=0,database[n.chat]={id:i,chat:await d.sendMessage(n.chat,{image:{url:e},caption:s},{quoted:n,ephemeralExpiration:n.expiration}),jawaban:a.toLowerCase(),hadiah:t,waktu:setTimeout(function(){database[n.chat].id==i&&(d.reply(n.chat,`Waktu habis!

Jawabannya adalah: `+r.texted("monospace",a),database[n.chat].chat,{expiration:n.expiration}),delete database[n.chat])},1e3*o.gamewaktu)}}},1e3)):/conversation|extendedTextMessage/.test(n.mtype)&&await d.sendReact(n.chat,"❌",n.key))}};