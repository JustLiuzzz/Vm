//CREATE BY REZA DEVS KUROMI
let fetch=require("node-fetch"),util=require("util"),gamesUrl="https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/kbbi.json",random=a=>a[Math.floor(Math.random()*a.length)];function rwd(a,e){return a=Math.ceil(a),e=Math.floor(e),Math.floor(Math.random()*(e-a+1))+a}async function genKata(){return new Promise(async a=>{let e=await fetch(gamesUrl).then(a=>a.json()),t=random(["a","b","c","d","e","g","h","i","j","k","l","m","n","p","r","s","t","u","w"]),r=e.filter(a=>a.startsWith(t)),n=random(r);for(;n.length<3;)n=random(r);a(n)})}async function cekKata(e=""){return new Promise(async a=>{(await fetch(gamesUrl).then(a=>a.json())).find(a=>a==e.toLowerCase())?a(!0):a(!1)})}function filter(a){let e=["q","w","r","t","y","p","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m"];if(/[aiueo][aiueo]([qwrtypsdfghjklzxcvbnm])?$/i.test(a))return a.substring(a.length-1);var t,r=Array.from(a).filter(a=>e.includes(a));let n=r[r.length-1];for(t of e)a.endsWith(t)&&(n=r[r.length-2]);var i=a.split(n);return n+i[i.length-1]}exports.run={usage:["sambungkata"],hidden:["sk"],use:"options",category:"games",async:async(l,{func:s,kuromi:p})=>{p.skata2=p.skata2||{};try{let a=`*Sambung Kata Help*

1. Permainan harus dimainkan minimal 2 pemain
2. Saat permainan dimulai bot akan memberikan 1 kata
3. Kemudian, player harus membuat 1 kata dari suku kata terakhir dari kata sebelumnya
4. Contohnya: *Teknologi*, maka jawabannya *Gigih* atau *Girang*
5. Permainan akan terus diulang sampai ada yang kalah
6. Tiap pemain diberi waktu 30 detik untuk menjawab
7. Tiap pemain diberi 3 kesempatan untuk menjawab
8. Kata yang dijawab harus terdaftar dalam KBBI dan belum pernah dijawab
9. Apabila benar, akan diberikan balance sesuai jumlah huruf kata yang dijawab dikali 100
10. Apabila 3 kesempatan atau waktu telah habis, player akan diberikan minus(-) balance dari kalkulasi jumlah balance yang telah diberikan pada permainan.`.trim(),t=l.chat,e,r=`Kirim perintah :

- ${l.cmd} help
- ${l.cmd} join
- ${l.cmd} start
- ${l.cmd} exit
- ${l.cmd} delete
- ${l.cmd} player

Minimal 2 orang`.trim(),n=(t in p.skata2||(e=await genKata(),p.skata2[t]={owner:l.sender,player:[],status:"wait",basi:[],point:0,chance:0,index:0,current:"",kata:e,genKata:genKata,cekKata:cekKata,filter:filter,chat:!1,timer:20,timeout:!1}),(l.args[0]||"").toLowerCase()),i=(!n&&p.skata2[t]&&(p.skata2[t].chat=await p.reply(t,r,l,{expiration:l.expiration})),p.skata2[t]);switch(n){case"help":case"rules":case"menu":p.reply(t,a,l,{expiration:l.expiration});break;case"join":if(s.ceklimit(l.sender,1))return l.reply(global.mess.limit);if(i.player.find(a=>a.id==l.sender))return l.reply("kamu sudah berada didalam list");p.skata2[t].player.push({id:l.sender,chance:3}),l.reply((`Berhasil masuk
Jumlah pemain: `+i.player.length).trim());break;case"exit":if(!i)return l.reply("Tidak ada sesi permainan");if(!i.player.find(a=>a.id==l.sender))return l.reply("Kamu tidak dalam sesi permainan.");if("play"==i.status)return l.reply("Permainan sudah dimulai, kamu tidak bisa keluar");var u=i.player.findIndex(a=>a.id===l.sender);i.player.splice(u,1),l.reply(`@${l.sender.split("@")[0]} keluar dari permainan.`);break;case"delete":if(!i)return l.reply("Tidak ada sesi permainan.");if(i.owner!==l.sender&&"play"==i.status)return l.reply(`Hanya @${i.owner.split("@")[0]} yang dapat menghapus sesi permainan ini.`);p.reply(t,"Sesi permainan berhasil dihapus.",l,{expiration:l.expiration}),i.timeout&&clearTimeout(i.timeout),delete p.skata2[t];break;case"player":if(!i)return l.reply("Tidak ada sesi permainan.");if(!i.player.find(a=>a.id==l.sender))return l.reply("Kamu tidak dalam sesi permainan.");if(0==i.player.length)return l.reply("Sesi permainan belum memiliki player.");var c="*S A M B U N G - K A T A*\n\nLIST PLAYER:\n";c+=i.player.map((a,e)=>e+1+". @"+a.id.split("@")[0]).join("\n"),p.reply(t,c.trim(),l,{expiration:l.expiration});break;case"start":if(i.player.length<2)return l.reply("Minimal 2 player.");if("wait"!==i.status)return p.reply(t,"Room sambungkata ini belum selesai",i.chat,{expiration:l.expiration}),!1;i.current=i.player[0].id,i.index=0,i.status="play";for(var o of i.player){var m=global.db.users[o.id];m.game||(m.game={}),m.game.hasOwnProperty("sambungkata")||(m.game.sambungkata=0)}c=`Giliran @${i.current.split("@")[0]}
Kata : *${i.kata}*
Waktu: ${i.timer}s
Kesempatan: ${i.player[i.index].chance}
		
Carilah kata yang berawalan *${i.filter(i.kata)}*`,i.chat=await p.reply(t,c.trim(),null,{mentions:[i.current],expiration:l.expiration}),i.point=100*i.kata.length;let e=()=>setTimeout(async()=>{p.reply(t,`Waktu habis @${i.current.split("@")[0]} tereliminasi.
Hadiah: -${i.point} balance`,i.chat,{mentions:[i.current],expiration:l.expiration}),global.db.users[i.current].balance-=i.point;var a=i.index;if(i.player.splice(i.index,1),i.current=(1<i.player.length?i.player[a]:i.player[0])?.id,console.log("room skata1:",i),1==i.player.length&&"play"==i.status)return global.db.users[i.current].game.sambungkata+=1,global.db.users[i.current].balance+=i.point,p.reply(l.chat,`@${i.current.split("@")[0]} Menang
Hadiah: $${i.point} balance`,i.chat,{mentions:[i.current],expiration:l.expiration}),delete p.skata2[t],!1;i.kata=await i.genKata(),a=`Lanjut Giliran @${i.current.split("@")[0]}
Kata: *${i.kata}*
Waktu: ${i.timer}s
Kesempatan: ${i.player[i.index].chance}

Carilah kata yang berawalan *${i.filter(i.kata)}*`.trim(),i.chat=await p.reply(l.chat,a,null,{mentions:[i.current],expiration:l.expiration}),i.point=100*i.kata.length,i.timeout=e()},1e3*i.timer);return i.timeout=e(),i}}catch(s){console.log(s),p.reply(l.chat,s.message,l,{expiration:l.expiration})}},main:async(i,{kuromi:l})=>{if(l.skata2=l.skata2||{},i.chat in l.skata2&&i.budy){let n=i.chat;if(l.skata2[n]){let r=l.skata2[n];if("play"===r.status&&r.current===i.sender){var a=i.budy.toLowerCase().split(" ")[0].trim().replace(/[^a-z]/gi,""),s=await r.cekKata(a),p=100*a.length;if(a.startsWith(r.filter(r.kata))){if(r.filter(r.kata)==a){let t="Jawaban kamu sama dengan soal\n";if(r.player[r.index].chance<=1||0==r.player[r.index].chance)if(global.db.users[r.curret].balance-=p,1<r.player.length){r.player.splice(r.index,1),r.index>=r.player.length&&(r.index=0),r.current=r.player[r.index].id,r.kata=await r.genKata(),t=`Lanjut Giliran @${r.current.split("@")[0]}
Kata: *${r.kata}*
Waktu: ${r.timer}s
Kesempatan: ${r.player[r.index].chance}

Carilah kata yang berawalan *${r.filter(r.kata)}*`.trim(),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration});let e=()=>setTimeout(async()=>{l.reply(n,`Waktu habis @${r.current.split("@")[0]} tereliminasi.
Hadiah: -${r.point} balance`,r.chat,{mentions:[r.current],expiration:i.expiration}),global.db.users[r.current].balance-=r.point;var a=r.index;if(r.player.splice(r.index,1),r.current=(1<r.player.length?r.player[a]:r.player[0])?.id,console.log("room skata1:",r),1==r.player.length&&"play"==r.status)return global.db.users[r.current].game.sambungkata+=1,global.db.users[r.current].balance+=r.point,l.reply(i.chat,`@${r.current.split("@")[0]} Menang
Hadiah: $${r.point} balance`,r.chat,{mentions:[r.current],expiration:i.expiration}),delete l.skata2[n],!1;r.kata=await r.genKata(),t=`Lanjut Giliran @${r.current.split("@")[0]}
Kata: *${r.kata}*
Waktu: ${r.timer}s
Kesempatan: ${r.player[r.index].chance}

Carilah kata yang berawalan *${r.filter(r.kata)}*`.trim(),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration}),r.point=100*r.kata.length,r.timeout=e()},1e3*r.timer);r.timeout=e()}else if(1==r.player.length)return r.current=r.player[0].id,global.db.users[r.current].balance+=100*r.kata.length,global.db.users[r.current].game.sambungkata+=1,t=`Pemenang: @${r.current.split("@")[0]}
Hadiah: ${100*r.kata.length} balance
Game Berakhir!`.trim(),r.timeout&&clearTimeout(r.timeout),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration}),delete l.skata2[n],!0;return--r.player[r.index].chance,i.reply(t+("Sisa kesempatan: "+r.player[r.index].chance))}if(r.basi.includes(a)){let t=`*${i.budy.toLowerCase()}* sudah pernah digunakan
`;if(r.player[r.index].chance<=1||0==r.player[r.index].chance)if(global.db.users[r.current].balance-=p,t+=`@${r.current.split("@")[0]} tereliminasi.
Hadiah: -${p} balance`,1<r.player.length){r.player.splice(r.index,1),r.index>=r.player.length&&(r.index=0),r.current=r.player[r.index].id,r.kata=await r.genKata(),t=`Lanjut Giliran @${r.current.split("@")[0]}
Kata: *${r.kata}*
Waktu: ${r.timer}s
Kesempatan: ${r.player[r.index].chance}

Carilah kata yang berawalan *${r.filter(r.kata)}*`.trim(),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration});let e=()=>setTimeout(async()=>{l.reply(n,`Waktu habis @${r.current.split("@")[0]} tereliminasi.
Hadiah: -${r.point} balance`,r.chat,{mentions:[r.current],expiration:i.expiration}),global.db.users[r.current].balance-=r.point;var a=r.index;if(r.player.splice(r.index,1),r.current=(1<r.player.length?r.player[a]:r.player[0])?.id,console.log("room skata1:",r),1==r.player.length&&"play"==r.status)return global.db.users[r.current].game.sambungkata+=1,global.db.users[r.current].balance+=r.point,l.reply(i.chat,`@${r.current.split("@")[0]} Menang
Hadiah: $${r.point} balance`,r.chat,{mentions:[r.current],expiration:i.expiration}),delete l.skata2[n],!1;r.kata=await r.genKata(),t=`Lanjut Giliran @${r.current.split("@")[0]}
Kata: *${r.kata}*
Waktu: ${r.timer}s
Kesempatan: ${r.player[r.index].chance}

Carilah kata yang berawalan *${r.filter(r.kata)}*`.trim(),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration}),r.point=100*r.kata.length,r.timeout=e()},1e3*r.timer);r.timeout=e()}else if(1==r.player.length)return r.current=r.player[0].id,global.db.users[r.current].balance+=100*r.kata.length,global.db.users[r.current].game.sambungkata+=1,t=`Pemenang: @${r.current.split("@")[0]}
Hadiah: ${100*r.kata.length} balance
Game Berakhir!`.trim(),r.timeout&&clearTimeout(r.timeout),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration}),delete l.skata2[n],!0;return--r.player[r.index].chance,i.reply(t+"Sisa kesempatan: "+r.player[r.index].chance)}if(!s){let t=`*${i.budy.toLowerCase()}* tidak terdaftar di KBBI
`;if(r.player[r.index].chance<=1||0==r.player[r.index].chance)if(global.db.users[r.current].balance-=p,1<r.player.length){r.player.splice(r.index,1),r.index>=r.player.length&&(r.index=0),r.current=r.player[r.index].id,r.kata=await r.genKata(),t=`Lanjut Giliran @${r.current.split("@")[0]}
Kata: *${r.kata}*
Waktu: ${r.timer}s
Kesempatan: ${r.player[r.index].chance}

Carilah kata yang berawalan *${r.filter(r.kata)}*`.trim(),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration});let e=()=>setTimeout(async()=>{l.reply(n,`Waktu habis @${r.current.split("@")[0]} tereliminasi.
Hadiah: -${r.point} balance`,r.chat,{mentions:[r.current],expiration:i.expiration}),global.db.users[r.current].balance-=r.point;var a=r.index;if(r.player.splice(r.index,1),r.current=(1<r.player.length?r.player[a]:r.player[0])?.id,console.log("room skata1:",r),1==r.player.length&&"play"==r.status)return global.db.users[r.current].game.sambungkata+=1,global.db.users[r.current].balance+=r.point,l.reply(i.chat,`@${r.current.split("@")[0]} Menang
Hadiah: $${r.point} balance`,r.chat,{mentions:[r.current],expiration:i.expiration}),delete l.skata2[n],!1;r.kata=await r.genKata(),t=`Lanjut Giliran @${r.current.split("@")[0]}
Kata: *${r.kata}*
Waktu: ${r.timer}s
Kesempatan: ${r.player[r.index].chance}

Carilah kata yang berawalan *${r.filter(r.kata)}*`.trim(),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration}),r.point=100*r.kata.length,r.timeout=e()},1e3*r.timer);r.timeout=e()}else if(1==r.player.length)return r.current=r.player[0].id,global.db.users[r.current].balance+=100*r.kata.length,global.db.users[r.current].game.sambungkata+=1,t=`Pemenang: @${r.current.split("@")[0]}
Hadiah: ${100*r.kata.length} balance
Game Berakhir!`.trim(),r.timeout&&clearTimeout(r.timeout),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration}),delete l.skata2[n],!0;return--r.player[r.index].chance,i.reply(t+"Sisa kesempatan: "+r.player[r.index].chance)}clearTimeout(r.timeout),global.db.users[r.current].balance+=p,global.db.users[r.current].game.sambungkata+=1,r.basi.push(a),s=r.index,console.log("INDEX CURRENT: ",s),console.log("OLD CURRENT: ",r.current),r.current=r.player[s+1]?.id,console.log("NEW CURRENT: ",r.current),r.current&&(r.index=s+1),s+1>=r.player.length&&(l.logger.warn(`
current: ${r.index+1}
player length: ${r.player.length}
Player: `+util.format(r.player)),r.current=r.player[0].id,r.index=0),r.kata=a;let e=`*Jawaban benar!*
Hadiah: ${p} balance
Giliran: @${r.current.split("@")[0]}
Kata: *${r.kata}*
Waktu: ${r.timer}s
Kesempatan: ${r.player[r.index].chance}

Carilah kata yang berawalan *${r.filter(r.kata)}*`.trim(),t=(r.chat=await i.reply(e,null,{mentions:[r.current],expiration:i.expiration}),()=>setTimeout(async()=>{l.reply(n,`Waktu habis @${r.current.split("@")[0]} tereliminasi.
Hadiah: -${r.point} balance`,r.chat,{mentions:[r.current],expiration:i.expiration}),global.db.users[r.current].balance-=r.point;var a=r.index;if(r.player.splice(r.index,1),r.current=(1<r.player.length?r.player[a]:r.player[0])?.id,console.log("room skata1:",r),1==r.player.length&&"play"==r.status)return global.db.users[r.current].game.sambungkata+=1,global.db.users[r.current].balance+=r.point,l.reply(i.chat,`@${r.current.split("@")[0]} Menang
Hadiah: $${r.point} balance`,r.chat,{mentions:[r.current],expiration:i.expiration}),delete l.skata2[n],!1;r.kata=await r.genKata(),e=`Lanjut Giliran @${r.current.split("@")[0]}
Kata: *${r.kata}*
Waktu: ${r.timer}s
Kesempatan: ${r.player[r.index].chance}

Carilah kata yang berawalan *${r.filter(r.kata)}*`.trim(),r.chat=await l.reply(i.chat,e,null,{mentions:[r.current],expiration:i.expiration}),r.point=100*r.kata.length,r.timeout=t()},1e3*r.timer));return r.timeout=t(),r}}}}},group:!0,location:"plugins/games/sambungkata.js"};