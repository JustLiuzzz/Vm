//CREATE BY REZA DEVS KUROMI
exports.run={usage:["petakbom","delpetakbom"],category:"games",async:async(a,{func:e,kuromi:b})=>{switch(a.command){case"petakbom":if(e.ceklimit(a.sender,1))return a.reply(global.mess.limit);if(a.sender in global.db.petakbom)return a.reply(`Game mu masih belum terselesaikan, lanjutkan yukk

${global.db.petakbom[a.sender].board.join("")}

Kirim ${a.prefix}delpetakbom untuk menghapus game petak bom`);var o=e.randomNomor(3e3,5e3),o=(global.db.petakbom[a.sender]={petak:[0,0,0,2,0,2,0,2,0,0].sort(()=>Math.random()-.5),board:["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣","🔟"],bomb:3,lolos:7,pick:0,hadiah:o,nyawa:["❤️","❤️","❤️"]},`PETAK BOM

${global.db.petakbom[a.sender].board.join("")}

Pilih lah nomor tersebut! dan jangan sampai terkena Bom!
Bomb: ${global.db.petakbom[a.sender].bomb}
Nyawa: `+global.db.petakbom[a.sender].nyawa.join(""));b.reply(a.chat,o,a);break;case"delpetakbom":if(!(a.sender in global.db.petakbom))return a.reply("kamu sedang tidak bermain petakbom!");delete global.db.petakbom[a.sender],a.reply("Berhasil menghapus game petak bomb")}},main:async(a,{})=>{var e,b;if(a.sender in global.db.petakbom)return e=global.db.petakbom[a.sender],!/^[1-9]|10$/i.test(a.budy)&&!a.isPrefix||1===e.petak[parseInt(a.budy)-1]||(2===e.petak[parseInt(a.budy)-1]?(e.board[parseInt(a.budy)-1]="💣",e.pick++,e.bomb--,e.nyawa.pop(),b=e.board,e.nyawa.length<1?(await a.reply(`GAME TELAH BERAKHIR
Kamu terkena bomb

 ${b.join("")}

Terpilih: ${e.pick}
Nyawamu habis... balance -`+e.hadiah),global.db.users[a.sender].balance-=e.hadiah,delete global.db.petakbom[a.sender]):await a.reply(`PETAK BOM

Kamu terkena bomb
 ${b.join("")}

Terpilih: ${e.pick}
Sisa nyawa: `+e.nyawa),!0):void(0===e.petak[parseInt(a.budy)-1]&&(e.petak[parseInt(a.budy)-1]=1,e.board[parseInt(a.budy)-1]="🌀",e.pick++,e.lolos--,b=e.board,e.lolos<1?(await a.reply(`Kamu berhasil menebak semuanya🥳
${b.join("")}

Terpilih: ${e.pick}
Sisa nyawa: ${e.nyawa}
Bomb: ${e.bomb}
Hadiah: $${e.hadiah} balance`),global.db.users[a.sender].balance+=e.hadiah,global.db.users[a.sender].game.petakbom+=1,delete global.db.petakbom[a.sender]):a.reply(`PETAK BOM

${b.join("")}

Terpilih: ${e.pick}
Sisa nyawa: ${e.nyawa}
Bomb: `+e.bomb))))}};