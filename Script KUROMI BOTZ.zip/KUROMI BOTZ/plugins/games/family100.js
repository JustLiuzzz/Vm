/* CODE LAIN CHEK
https://whatsapp.com/channel/0029VbARSvBCMY0PDV53rt0m
JANGAN LUPA FOLLOW
*/

//CREATE BY REZA DEVS KUROMI
let fetch = require("node-fetch"),
  similarity = require("similarity"),
  gamesUrl = "https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/family100.json",
  sensitive = 0.75,
  alreadyAnswered = new Set;

function answer(a, e) {
  let t = e.toLowerCase();
  return Array.isArray(a) ? a.some(a => similarity(a, t) >= sensitive) : similarity(a, t) >= sensitive;
}

function generateClue(answer) {
  // Split jawaban jika ada spasi
  let words = answer.split(" ");
  if (words.length > 1) {
    // Jika ada spasi, buat clue untuk setiap kata
    return words.map(word => {
      return word.length > 3 ? word.slice(0, 3) + "*".repeat(word.length - 3) : word.slice(0, 1) + "*".repeat(word.length - 1);
    }).join(" ");
  } else {
    // Jika tidak ada spasi, buat clue untuk kata tunggal
    return answer.length > 3 ? answer.slice(0, 3) + "*".repeat(answer.length - 3) : answer.slice(0, 1) + "*".repeat(answer.length - 1);
  }
}

exports.run = {
  usage: ["family100"],
  hidden: ["f100"],
  category: "games",
  async: async (t, { func: a, kuromi: i, setting: e }) => {
    if (i.family100 = i.family100 || {}, a.ceklimit(t.sender, 1)) return t.reply(global.mess.limit);
    if (t.chat in i.family100) return i.reply(t.chat, "⚠️ Masih ada soal belum terjawab di chat ini!", i.family100[t.chat].msg);

    var { soal: n, jawaban: r } = (await fetch(gamesUrl).then(a => a.json())).result.random();
    if (!Array.isArray(r)) return t.reply("❌ Terjadi kesalahan, silahkan kirim ulang " + t.cmd);

    var s, l = a.hadiah(e.hadiah), m = [], clues = [];
    for (s of r) {
      var o = (o = (o = s.split("/") ? s.split("/")[0] : s).startsWith(" ") ? o.replace(" ", "") : o).endsWith(" ") ? o.replace(o.slice(-1), "") : o;
      m.push(o.toLowerCase());
      clues.push(generateClue(o.toLowerCase())); // Generate clue untuk setiap jawaban
    }

    // Membuat tampilan soal lebih menarik
    let clueText = clues.map((clue, index) => `  ${index + 1}. ${clue}`).join("\n");
    a = `🎉 *FAMILY 100 GAMES* 🎉

🔥 *Soal Seru*: ${a.texted("bold", n)} 🔥

💡 *Clue Jawaban*:
${clueText}

🎯 *Total Jawaban*: ${r.length}
💰 *Hadiah*: $${l} balance
⏳ *Waktu*: ${e.gamewaktu} detik

💬 *Ayo tebak sekarang!* Ketik jawabanmu atau *nyerah* untuk soal baru!`;

    a = await i.reply(t.chat, a, t, { expiration: t.expiration });
    alreadyAnswered.clear();
    i.family100[t.chat] = {
      soal: n,
      jawaban: m,
      hadiah: l,
      total: r.length,
      players: [],
      nextQuestion: 1,
      timeout: setTimeout(function () {
        var a, e;
        t.chat in i.family100 && (e = `⌛ *Waktu habis!* 😢\nJawaban yang belum terjawab:\n` + (a = i.family100[t.chat]).jawaban.map(a => "➡️ " + a).join("\n"), i.reply(t.chat, e, a.msg, { expiration: t.expiration }), delete i.family100[t.chat]);
      }, 1e3 * e.gamewaktu),
      msg: a ? { key: a.key, message: a.message } : null
    };
  },

  main: async (m, { func: o, kuromi: h, setting: y }) => {
    if (h.family100 = h.family100 || {}, m.chat in h.family100 && !m.fromMe && !m.isPrefix) {
      let l = h.family100[m.chat];
      if (/nyerah/i.test(m.budy)) {
        if (o.ceklimit(m.sender, 1)) return m.reply(global.mess.limit);
        l.timeout && clearTimeout(l.timeout);
        l.nextQuestion++;
        let a = `🏳️ *Kamu menyerah!* 😔\nJawaban yang belum terjawab:\n` + l.jawaban.map(a => "➡️ " + a).join("\n"),
          s = await h.sendMessage(m.chat, { text: a }, { quoted: h.family100[m.chat].msg, ephemeralExpiration: m.expiration });

        return setTimeout(async () => {
          var a = (await fetch(gamesUrl).then(a => a.json())).result.random();
          if (!Array.isArray(a.jawaban)) return m.reply("❌ Terjadi kesalahan, silahkan kirim ulang " + m.cmd);
          var e, t = o.hadiah(y.hadiah), i = [], clues = [];
          for (e of a.jawaban) {
            var n = (n = (n = e.split("/") ? e.split("/")[0] : e).startsWith(" ") ? n.replace(" ", "") : n).endsWith(" ") ? n.replace(n.slice(-1), "") : n;
            i.push(n.toLowerCase());
            clues.push(generateClue(n.toLowerCase())); // Generate clue untuk soal berikutnya
          }

          let clueText = clues.map((clue, index) => `  ${index + 1}. ${clue}`).join("\n");
          var r = `🎉 *LANJUT SOAL KE-${l.nextQuestion}* 🎉

🔥 *Soal Baru*: ${o.texted("bold", a.soal)} 🔥

💡 *Clue Jawaban*:
${clueText}

🎯 *Total Jawaban*: ${a.jawaban.length}
💰 *Hadiah*: $${t} balance
⏳ *Waktu*: ${y.gamewaktu} detik

💬 *Ayo tebak lagi!* Ketik jawabanmu atau *nyerah* untuk soal baru!`;

          r = await h.sendMessage(m.chat, { text: r, edit: s.key }, { quoted: m, ephemeralExpiration: m.expiration });
          Object.assign(l, {
            soal: a.soal,
            jawaban: i,
            hadiah: t,
            total: a.jawaban.length,
            players: [],
            waktu: setTimeout(function () {
              var a;
              m.chat in h.family100 && (a = `⌛ *Waktu habis!* 😢\nJawaban yang belum terjawab:\n` + l.jawaban.map(a => "➡️ " + a).join("\n"), h.reply(m.chat, a, l.msg, { expiration: m.expiration }), delete h.family100[m.chat]);
            }, 1e3 * parseInt(y.gamewaktu)),
            msg: r ? { key: r.key, message: r.message } : null
          });
        }, 3e3), !1;
      }

      m.quoted && m.quoted.fromMe && m.quoted.id == h.family100[m.chat].msg.key.id && !answer(l.jawaban, m.budy.toLowerCase()) && /conversation|extendedTextMessage/.test(m.mtype) && y.incorrect && await h.sendMessage(m.chat, { react: { text: "❌", key: m.key } });

      for (var a of l.jawaban) {
        if (answer(a, m.budy.toLowerCase())) {
          if (alreadyAnswered.has(a)) return;
          alreadyAnswered.add(a);
          var e = l.jawaban.indexOf(a);
          l.players.push({ jid: m.sender, jawaban: a.toLowerCase() });
          l.jawaban.splice(e, 1);
          var text = m.isGc ? `🎉 *${l.soal}* 🎉

✅ *Jawaban Benar!* Terdapat *${l.total}* jawaban:
` + l.players.map((a, e) => `  ${e + 1}. ${a.jawaban} @` + a.jid.split("@")[0]).join("\n") + (l.jawaban.length < 1 ? `

🥳 *Selamat!* Semua jawaban sudah tertebak!
Main lagi? Kirim ${m.prefix}family100` : `

💰 *$${l.hadiah}* balance per jawaban benar
💬 Ketik *nyerah* untuk soal baru`) : `✅ *Jawaban Benar!* 🎉
Jawaban: ${a}

` + (l.jawaban.length < 1 ? `🥳 *Selamat!* Semua jawaban sudah tertebak!
Main lagi? Kirim ${m.prefix}family100` : `🔍 Jawaban yang belum tertebak: ${l.jawaban.length}`);

          h.reply(m.chat, text, m, { expiration: m.expiration });
          global.db.users[m.sender].balance += l.hadiah;
          global.db.users[m.sender].game.family100 += 1;

          if (l.jawaban.length < 1) {
            clearTimeout(l.timeout);
            delete h.family100[m.chat];
          }
        }
      }
    }
  },
  location: "plugins/games/family100.js"
};