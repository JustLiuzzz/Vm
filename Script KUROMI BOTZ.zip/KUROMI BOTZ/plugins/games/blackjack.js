//CREATE BY REZA DEVS KUROMI
class Blackjack{decks;state="waiting";player=[];dealer=[];table={player:{total:0,cards:[]},dealer:{total:0,cards:[]},bet:0,payout:0,doubleDowned:!1};cards;endHandlers=[];constructor(a){this.decks=validateDeck(a)}placeBet(a){if(a<=0)throw new Error("You must place a bet greater than 0");this.table.bet=a}start(){if(this.table.bet<=0)throw new Error("You must place a bet before starting the game");this.cards=new Deck(this.decks),this.cards.shuffleDeck(2),this.player=this.cards.dealCard(2);let a;for(;11<(a=this.cards.dealCard(1)[0]).value;);return this.dealer=[a,...this.cards.dealCard(1)],this.updateTable(),this.table}hit(){var a;if("waiting"===this.state)return a=this.cards.dealCard(1)[0],this.player.push(a),this.updateTable(),(a=sumCards(this.player))===sumCards(this.dealer)?(this.state="draw",this.emitEndEvent()):21===a?(this.state="player_blackjack",this.emitEndEvent()):21<a&&(this.state="dealer_win",this.emitEndEvent()),this.table}stand(){let a=sumCards(this.dealer),e=sumCards(this.player);if(e<=21)for(;a<17;)this.dealer.push(...this.cards.dealCard(1)),a=sumCards(this.dealer),this.updateTable();e<=21&&(21<a||a<e)?this.state=21===e?"player_blackjack":"player_win":a===e?this.state="draw":this.state=21===a?"dealer_blackjack":"dealer_win",this.emitEndEvent()}doubleDown(){if(!this.canDoubleDown())throw new Error("You can only double down on the first turn");this.table.doubleDowned=!0,this.player.push(...this.cards.dealCard(1)),this.updateTable(),this.stand()}calculatePayout(){"player_blackjack"===this.state?this.table.payout=1.5*this.table.bet:"player_win"===this.state?this.table.payout=this.table.bet:"dealer_win"===this.state||"dealer_blackjack"===this.state?this.table.payout=0:"draw"===this.state&&(this.table.payout=this.table.bet),this.table.doubleDowned&&"draw"!==this.state&&(this.table.payout*=2),this.table.payout=Math.round(this.table.payout)}canDoubleDown(){return"waiting"===this.state&&2===this.player.length}onEnd(a){this.endHandlers.push(a)}emitEndEvent(){this.calculatePayout();for(var a of this.endHandlers)a({state:this.state,player:formatCards(this.player),dealer:formatCards(this.dealer),bet:this.table.bet,payout:this.table.payout})}updateTable(){this.table.player=formatCards(this.player),this.table.dealer=formatCards(this.dealer)}}class Deck{deck=[];dealtCards=[];constructor(e){for(let a=0;a<e;a++)this.createDeck()}createDeck(){var t,r,s=["2","3","4","5","6","7","8","9","10","J","Q","K","A"],l=["♣️","♦️","♠️","♥️"];for(let e=0;e<l.length;e++)for(let a=0;a<s.length;a++)this.deck.push((t=l[e],{name:(r=s[a])+" of "+t,suit:t,value:+(r=(r=r.toUpperCase().includes("J")||r.toUpperCase().includes("Q")||r.toUpperCase().includes("K")?"10":r).toUpperCase().includes("A")?"11":r)}))}shuffleDeck(e=1){for(let a=0;a<e;a++)for(let t=this.deck.length-1;0<=t;t--){let a=this.deck[t],e=Math.floor(Math.random()*this.deck.length);for(;e===t;)e=Math.floor(Math.random()*this.deck.length);this.deck[t]=this.deck[e],this.deck[e]=a}}dealCard(e){var t=[];for(let a=0;a<e;a++){var r=this.deck.shift();r&&(t.push(r),this.dealtCards.push(r))}return t}}function sumCards(a){let e=0,t=0;for(var r of a)e+=r.value,t+=11===r.value?1:0;for(;21<e&&0<t;)e-=10;return e}function formatCards(a){return{total:sumCards(a),cards:a}}function validateDeck(a){if(!a)throw new Error("A deck must have a number of decks");if(a<1)throw new Error("A deck must have at least 1 deck");if(8<a)throw new Error("A deck can have at most 8 decks");return a}let formatter=new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR"});exports.run={usage:["blackjack"],hidden:["bj"],use:"options",category:"games",async:async(o,{kuromi:k,errorMessage:a})=>{k.blackjack=k.blackjack||{};var e,t,r,s,l,c=a=>{var{table:a,state:e}=a,{bet:t,dealer:r,player:a,payout:s}=a;let l="",c=r.cards.map(a=>""+a.name).join(", "),i=r.total,d=a.cards.map(a=>""+a.name).join(", "),n=a.total,h=r.cards.slice(0,-1).map(a=>""+a.name).join(", ");switch(1<r.cards.length?h+=", ❓":h+=", "+r.cards[0].name,e){case"player_win":case"dealer_win":case"draw":case"player_blackjack":case"dealer_blackjack":h=r.cards.map(a=>""+a.name).join(", "),l=`*\`🃏 • B L A C K J A C K •\`*

╭───┈ •
│ *Your Cards:*
│ \`${d}\`
│ *Your Total:*
│ \`${n}\`
├───┈ •
│ *Dealer's Cards:*
│ \`${c}\`
│ *Dealer's Total:*
│ \`${21<i?"BUST":i}\`
╰───┈ •

> *\`${("player_win"===e?"You win! 🎉":"dealer_win"===e?"Dealer wins. 😔":"draw"===e?"Draw. 🤝":"player_blackjack"===e?"Blackjack! 🥳":"Dealer got Blackjack! 😔").toUpperCase()}\`*
*Bet:*
- %${formatter.format(t)}%
*Payout:*
- %${formatter.format(s)}%`,global.db.users[k.blackjack[o.chat].idPemain].balance+=s,delete k.blackjack[o.chat];break;default:l=`*\`🃏 • B L A C K J A C K •\`*

╭───┈ •
│ *Your Cards:*
│ \`${d}\`
│ *Your Total:*
│ \`${n}\`
├───┈ •
│ *Dealer's Cards:*
│ \`${h}\`
│ *Dealer's Total:*
│ \`${21<i?"BUST":"❓"}\`
╰───┈ •

*Bet:*
- %${formatter.format(t)}%

Type *\`${o.cmd} hit\`* to draw a card.
Type *\`${o.cmd} stand\`* to end your turn.`}return l.replaceAll("%","```")},i=(o.args[0]||"").toLowerCase(),d=(o.args[1]||"").toLowerCase();try{switch(i){case"end":k.blackjack[o.chat]?.idPemain===o.sender?(delete k.blackjack[o.chat],await k.reply(o.chat,"*Anda keluar dari sesi blackjack.* 👋",o)):await k.reply(o.chat,"*Tidak ada sesi blackjack yang sedang berlangsung atau Anda bukan pemainnya.*",o,{expiration:o.expiration});break;case"start":k.blackjack[o.chat]?await k.reply(o.chat,`*Sesi blackjack sudah berlangsung.* Gunakan *${o.cmd} end* untuk keluar dari sesi.`,o):(k.blackjack[o.chat]=new Blackjack(1),k.blackjack[o.chat].idPemain=o.sender,e=d?parseInt(d):1e3,k.blackjack[o.chat].placeBet(e),k.blackjack[o.chat].start(),t=c(k.blackjack[o.chat]),await k.reply(o.chat,t,o));break;case"hit":k.blackjack[o.chat]&&k.blackjack[o.chat]?.idPemain===o.sender?(k.blackjack[o.chat].hit(),r=c(k.blackjack[o.chat]),await k.reply(o.chat,r,o)):await k.reply(o.chat,"*Anda tidak sedang bermain blackjack atau bukan pemainnya.*",o,{expiration:o.expiration});break;case"stand":k.blackjack[o.chat]&&k.blackjack[o.chat]?.idPemain===o.sender?(k.blackjack[o.chat].stand(),s=c(k.blackjack[o.chat]),await k.reply(o.chat,s,o)):await k.reply(o.chat,"*Anda tidak sedang bermain blackjack atau bukan pemainnya.*",o,{expiration:o.expiration});break;case"double":k.blackjack[o.chat]&&k.blackjack[o.chat]?.idPemain===o.sender?(k.blackjack[o.chat].doubleDown(),l=c(k.blackjack[o.chat]),await k.reply(o.chat,l,o)):await k.reply(o.chat,"*Anda tidak sedang bermain blackjack atau bukan pemainnya.*",o,{expiration:o.expiration});break;default:await k.reply(o.chat,`*Perintah tidak valid.*
Gunakan *${o.cmd} start* untuk memulai sesi blackjack.`,o,{expiration:o.expiration})}}catch(e){return await k.reply(o.chat,"*Terjadi kesalahan saat memproses perintah.*",o),a(e)}},limit:!0};