exports.run = {
    usage: ['kerja'],
    hidden: [],
    use: 'Lakukan pekerjaan untuk mendapatkan uang dan EXP',
    category: 'games',
    async: async (m, { func, kuromi, isPrem, users }) => {
        const jobs = {
            ojek: { name: 'Ojek', task: '🛵 Mengantarkan penumpang', difficulty: pickRandom(['Noob', 'Easy', 'Normal']), money: randomMoney(50000, 1), exp: 15 },
            pedagang: { name: 'Pedagang', task: '🛒 Mencari pembeli', difficulty: pickRandom(['Noob', 'Easy', 'Normal']), money: randomMoney(50000, 1), exp: 25 },
            dokter: { name: 'Dokter', task: '💉 Merawat pasien', difficulty: pickRandom(['Easy', 'Normal', 'Hard']), money: randomMoney(50000, 1), exp: 40 },
            petani: { name: 'Petani', task: '🌾 Menanam dan memanen tanaman', difficulty: pickRandom(['Noob', 'Easy', 'Normal']), money: randomMoney(50000, 1), exp: 30 },
            youtuber: { name: 'Youtuber', task: '📱 Membuat konten video youtube', difficulty: pickRandom(['Noob', 'Easy', 'Normal']), money: randomMoney(50000, 1), exp: 30 },
            montir: { name: 'Montir', task: '🔧 Memperbaiki kendaraan', difficulty: pickRandom(['Easy', 'Normal', 'Hard']), money: randomMoney(50000, 1), exp: 20 },
            kuli: { name: 'Kuli', task: '🏋️ Membantu proyek konstruksi', difficulty: 'Extreme', money: randomMoney(50000, 1), exp: 50 },
            gamer: { name: 'Gamer', task: '🎮 Main game dan streaming', difficulty: pickRandom(['Noob', 'Easy', 'Normal', 'Hard']), money: randomMoney(50000, 1), exp: 10 },
            teacher: { name: 'Teacher', task: '👩‍🏫 Mengajar dan memberi pembelajaran', difficulty: pickRandom(['Noob', 'Easy', 'Normal', 'Hard']), money: randomMoney(50000, 1), exp: 35 },
            designer: { name: 'Graphic Designer', task: '🎨 Membuat desain grafis', difficulty: pickRandom(['Easy', 'Normal', 'Hard']), money: randomMoney(50000, 1), exp: 28 },
        };

        let timeNow = Date.now();
        let cooldown = 86400000; // 24 jam dalam milidetik

        kuromi.lastWorkTime = kuromi.lastWorkTime || {};
        users.job = users.job || null; // Simpan pekerjaan pengguna

        if (!users.job) {  
            // Jika pengguna belum memilih pekerjaan
            const jobFields = Object.keys(jobs).map((field, index) => `*${index + 1}.* ${field}`).join('\n');
            return m.reply(`ℹ️ Pilih pekerjaan terlebih dahulu:\n${jobFields}\n\nContoh: ketik *skerja petani* untuk bekerja di pertanian`);
        }

        let type = users.job;
        let jobData = jobs[type];

        if (timeNow - (kuromi.lastWorkTime[m.sender] || 0) < cooldown) {
            let remainingTime = cooldown - (timeNow - kuromi.lastWorkTime[m.sender]);
            return m.reply(`😴 Kamu sudah bekerja, istirahat dulu selama\n${clockString(remainingTime)}`);
        }

        // Hitung pendapatan
        const earnedMoney = jobData.money * (jobData.difficulty === 'Extreme' ? 2 : jobData.difficulty === 'Hard' ? 2 : 1) * 3;
        const earnedExp = jobData.exp * 10;
        users.money = (users.money || 0) + earnedMoney;
        users.exp = (users.exp || 0) + earnedExp;
        kuromi.lastWorkTime[m.sender] = timeNow;

        const message = `👷 Kamu bekerja sebagai *${jobData.name}*\nTugas: ${jobData.task}\nTingkat Kesulitan: ${jobData.difficulty}\n\n💰 Gaji: *${earnedMoney.toLocaleString()}*\n🔼 EXP: *${earnedExp}*`;
        m.reply(message);

        setTimeout(() => {
            m.reply("Waktumu untuk bekerja sudah tiba! Kamu bisa bekerja lagi sekarang.");
        }, cooldown);
    }
};

// Helper Functions
function pickRandom(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

function randomMoney(max, min) {
    const maxSalary = 3000000;
    const randomSalary = Math.floor(Math.random() * (max - min + 1)) + min;
    return Math.min(randomSalary, maxSalary);
}

function clockString(ms) {
    let d = Math.floor(ms / 86400000);
    let h = Math.floor(ms / 3600000) % 24;
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [`\n${d} *Hari ☀️*\n`, h, ' *Jam 🕐*\n', m, ' *Menit ⏰*\n', s, ' *Detik ⏱️* '].join('');
}