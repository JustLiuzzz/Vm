//CREATE BY REZA DEVS KUROMI
let similarity=require("similarity"),gamesUrl="https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/tebakbendera.json",sensitive=.75,database={},player=0;exports.run={usage:["tebakbendera"],hidden:["tbendera"],category:"games",async:async(a,{func:e,kuromi:t,setting:s,users:i})=>{if(e.ceklimit(a.sender,1))return a.reply(global.mess.limit);if(a.chat in database)return t.reply(a.chat,"Masih ada soal belum terjawab di chat ini",database[a.chat].chat);let{soal:n,jawaban:r}=(await fetch(gamesUrl).then(a=>a.json())).result.random(),d=e.hadiah(s.hadiah),l=Date.now();i=`*G A M E - T E B A K B E N D E R A*

Soal: ${e.texted("monospace",n)}
${i.premium?"\nPetunjuk: "+e.texted("monospace",r.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi,"-")):""}
Hadiah: $${d} balance
Waktu: ${s.gamewaktu} detik`,player=0,database[a.chat]={id:l,chat:await t.reply(a.chat,i,a,{expiration:a.expiration}),soal:n,jawaban:r.toLowerCase(),hadiah:d,waktu:setTimeout(function(){database[a.chat].id==l&&(t.reply(a.chat,`Waktu habis!

Jawabannya adalah: `+e.texted("monospace",r),database[a.chat].chat,{expiration:a.expiration}),delete database[a.chat])},1e3*s.gamewaktu)}},main:async(i,{func:n,kuromi:r,setting:d,users:l})=>{var a,e,t,s;i.chat in database&&!i.fromMe&&!i.isPrefix&&({soal:a,jawaban:e,hadiah:t,waktu:s}=database[i.chat],similarity(e,i.budy.toLowerCase())>=sensitive?(player++,await r.sendReact(i.chat,"✅",i.key),global.db.users[i.sender].balance+=t,global.db.users[i.sender].game.tebakbendera+=1,clearTimeout(s),delete database[i.chat],setTimeout(async()=>{if(!(1<player)){if(global.db.users[i.sender].limit<1)return i.reply("Soal dihentikan karena limit kamu sudah habis.");--global.db.users[i.sender].limit;let a=(await fetch(gamesUrl).then(a=>a.json())).result.random(),e=n.hadiah(d.hadiah),t=Date.now(),s=`*LANJUT SOAL BERIKUTNYA*

Soal: ${n.texted("monospace",a.soal)}
${l.premium?"\nPetunjuk: "+n.texted("monospace",a.jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi,"-")):""}
Hadiah: $${e} balance
Waktu: ${d.gamewaktu} detik`;player=0,database[i.chat]={id:t,chat:await r.reply(i.chat,s,i,{expiration:i.expiration}),soal:a.soal,jawaban:a.jawaban.toLowerCase(),hadiah:e,waktu:setTimeout(function(){database[i.chat].id==t&&(r.reply(i.chat,`Waktu habis!

Jawabannya adalah: `+n.texted("monospace",a.jawaban),database[i.chat].chat,{expiration:i.expiration}),delete database[i.chat])},1e3*d.gamewaktu)}}},1e3)):/conversation|extendedTextMessage/.test(i.mtype)&&await r.sendReact(i.chat,"❌",i.key))}};