//CREATE BY REZA DEVS KUROMI
let fs=require("fs");exports.run={usage:["casino","delcasino"],use:"nominal @tag",category:"games",async:async(n,{func:a,kuromi:e})=>{switch(n.command){case"casino":if(!n.text)return n.reply(`Kirim perintah *${n.cmd}* nominal @tag`);if(Object.values(global.db.casino).find(a=>a.id.startsWith("casino")&&[a.penantang,a.ditantang].includes(n.sender)))return n.reply("Selesaikan casino mu yang sebelumnya.");if(a.ceklimit(n.sender,1))return n.reply(global.mess.limit);if(n.text&&n.quoted&&n.quoted.sender){var i=n.args[0].toString().replace(/[^0-9]/g,""),t=n.quoted.sender;if(!i)return n.reply("Masukan nominalnya.");if(i.includes("-"))return n.reply("Jangan menggunakan -");if(isNaN(parseInt(i)))return n.reply("Nominal harus berupa angka!");if(i<1e3)return n.reply("Minimal 1000 untuk bisa casino!");if(t===n.bot)return n.reply("Tidak bisa bermain dengan bot!");if(t===n.sender)return n.reply("Sad amat main ama diri sendiri");var l=global.db.users[n.sender].balance,s=global.db.users[t].balance;if(l<i||null==l)return n.reply(`Balance tidak mencukupi, kumpulkan terlebih dahulu
Ketik ${n.prefix}balance untuk mengecek balancemu.`);if(s<i||null==s)return n.reply(`Balance lawan tidak mencukupi untuk bermain denganmu
Ketik ${n.prefix}balance @${t.split("@")[0]} untuk mengecek balance lawanmu.`);l="casino_"+Date.now(),global.db.casino[l]={id:l,penantang:n.sender,ditantang:t,nominal:parseInt(i)},s=`Memulai Game Casino

@${n.sender.split("@")[0]} menantang @${t.split("@")[0]} dengan nominal *$${a.formatNumber(i)}* balance

Ketik *Y/N* untuk menerima atau menolak permainan!`,e.sendMessage(n.chat,{text:s,mentions:[n.sender,t]},{quoted:n,ephemeralExpiration:n.expiration})}else if(n.text){if(l=n.args[0].toString().replace(/[^0-9]/g,""),i=n.text.slice(n.args[0].length+1,n.text.length).replace(/[^0-9]/g,"")+"@s.whatsapp.net",!l)return n.reply("Masukan nominalnya.");if(l.includes("-"))return n.reply("Jangan menggunakan -");if(isNaN(parseInt(l)))return n.reply("Nominal harus berupa angka!");if(l<1e3)return n.reply("Minimal 1000 untuk bisa casino!");if("@s.whatsapp.net"===i)return n.reply(global.mess.wrongFormat);if(i===n.bot)return n.reply("Tidak bisa bermain dengan bot!");if(i===n.sender)return n.reply("Sad amat main ama diri sendiri");if(null==global.db.users[i])return n.reply("User data not found.");if(s=global.db.users[n.sender].balance,t=global.db.users[i].balance,s<l||null==s)return n.reply(`Balance tidak mencukupi, kumpulkan terlebih dahulu
Ketik ${n.prefix}balance untuk mengecek balancemu.`);if(t<l||null==t)return n.reply(`Balance lawan tidak mencukupi untuk bermain denganmu
Ketik ${n.prefix}balance @${i.split("@")[0]} untuk mengecek balance lawanmu.`);s="casino_"+Date.now(),global.db.casino[s]={id:s,penantang:n.sender,ditantang:i,nominal:parseInt(l)},t=`Memulai Game Casino

@${n.sender.split("@")[0]} menantang @${i.split("@")[0]} dengan nominal *$${a.formatNumber(l)}* balance

Ketik *Y/N* untuk menerima atau menolak permainan!`,e.sendMessage(n.chat,{text:t,mentions:[n.sender,i]},{quoted:n,ephemeralExpiration:n.expiration})}else n.reply(a.example(n.prefix+n.command,`2000 @${global.mark.split("@")[0]} `));break;case"delcasino":(s=Object.values(global.db.casino).find(a=>a.id.startsWith("casino")&&[a.penantang,a.ditantang].includes(n.sender)))?s.penantang.includes(n.sender)||s.ditantang.includes(n.sender)?(delete global.db.casino[s.id],n.reply("Berhasil menghapus sesi casino.")):n.reply("Anda tidak bisa menghapus sesi casino, karena bukan pemain!"):n.reply("Tidak ada sesi yang berlangsung.")}},main:async(n,{func:a,kuromi:e})=>{var i,t,l,s;Object.values(global.db.casino).find(a=>a.id.startsWith("casino")&&[a.penantang,a.ditantang].includes(n.sender))&&(i=Object.values(global.db.casino).find(a=>a.id.startsWith("casino")&&[a.penantang,a.ditantang].includes(n.sender)),n.sender==i.ditantang&&"n"===n.budy.toLowerCase()&&(e.sendMessage(n.chat,{text:`GAME CASINO REJECTED

@${i.ditantang.split("@")[0]} Membatalkan Game`,mentions:[i.ditantang]},{quoted:n,ephemeralExpiration:n.expiration}),delete global.db.casino[i.id]),n.sender==i.ditantang)&&"y"===n.budy.toLowerCase()&&(t=await a.randomNomor(10,20),(l=await a.randomNomor(10,20))<t?(s=`乂  *CASINO GAME*

◦ @${i.penantang.split("@")[0]} --> ${t}
◦ @${i.ditantang.split("@")[0]} --> ${l}

Pemenangnya adalah: @${i.penantang.split("@")[0]}
Hadiah: $`+a.formatNumber(i.nominal),e.sendMessage(n.chat,{text:s,mentions:[i.penantang,i.ditantang]},{quoted:n,ephemeralExpiration:n.expiration}),global.db.users[i.penantang].balance+=i.nominal,global.db.users[i.ditantang].balance-=i.nominal,global.db.users[i.penantang].game.casino+=1,delete global.db.casino[i.id]):t<l?(s=`乂  *CASINO GAME*

◦ @${i.penantang.split("@")[0]} --> ${t}
◦ @${i.ditantang.split("@")[0]} --> ${l}

Pemenangnya adalah: @${i.ditantang.split("@")[0]}
Hadiah: $`+a.formatNumber(i.nominal),e.sendMessage(n.chat,{text:s,mentions:[i.penantang,i.ditantang]},{quoted:n,ephemeralExpiration:n.expiration}),global.db.users[i.ditantang].balance+=i.nominal,global.db.users[i.penantang].balance-=i.nominal,global.db.users[i.ditantang].game.casino+=1,delete global.db.casino[i.id]):t==l&&(a=`乂  *CASINO GAME*

◦ @${i.penantang.split("@")[0]} --> ${t}
◦ @${i.ditantang.split("@")[0]} --> ${l}

Hasil Seri, Tidak Ada Pemenang.`,e.sendMessage(n.chat,{text:a,mentions:[i.penantang,i.ditantang]},{quoted:n,ephemeralExpiration:n.expiration}),delete global.db.casino[i.id]))},group:!0};