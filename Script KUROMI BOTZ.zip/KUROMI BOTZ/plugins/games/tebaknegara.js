//CREATE BY REZA DEVS KUROMI
let fetch=require("node-fetch"),similarity=require("similarity"),gamesUrl="https://api.vyturex.com/country",sensitive=.75,database={},player=0;exports.run={usage:["tebaknegara"],hidden:["tnegara"],category:"games",async:async(a,{func:e,kuromi:t,setting:i,isPrem:s})=>{if(e.ceklimit(a.sender,1))return a.reply(global.mess.limit);if(a.chat in database)return t.reply(a.chat,"Masih ada soal belum terjawab di chat ini",database[a.chat].chat);let{country:n,link:r}=await fetch(gamesUrl).then(a=>a.json()),d=e.hadiah(i.hadiah),h=Date.now();s=`*G A M E - T E B A K N E G A R A*

Soal: ${e.texted("monospace","Bendera negara apa ini?")}
${s?"\nPetunjuk: "+e.texted("monospace",n.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi,"-")):""}
Hadiah: $${d} balance
Waktu: ${i.gamewaktu} detik`,player=0,database[a.chat]={id:h,chat:await t.sendMessageModify(a.chat,s,a,{thumbUrl:r,largeThumb:!0,title:"GAME TEBAK NEGARA",body:"",expiration:a.expiration}),soal:"Bendera negara manakah itu?",jawaban:n.toLowerCase(),hadiah:d,waktu:setTimeout(async function(){database[a.chat].id==h&&(t.sendMessage(a.chat,{text:`Waktu habis!

Jawabannya adalah: `+e.texted("monospace",n)},{quoted:database[a.chat].chat,ephemeralExpiration:a.expiration}),delete database[a.chat])},1e3*i.gamewaktu)}},main:async(n,{func:r,kuromi:d,setting:h})=>{var a,e,t,i;n.chat in database&&!n.fromMe&&!n.isPrefix&&({soal:a,jawaban:e,hadiah:t,waktu:i}=database[n.chat],similarity(e,n.budy.toLowerCase())>=sensitive?(player++,d.sendMessage(n.chat,{react:{text:"✅",key:n.key}}),global.db.users[n.sender].balance+=t,global.db.users[n.sender].game.tebaknegara+=1,clearTimeout(i),delete database[n.chat],setTimeout(async()=>{if(!(1<player)){if(global.db.users[n.sender].limit<1)return n.reply("Soal dihentikan karena limit kamu sudah habis.");--global.db.users[n.sender].limit;let{country:a,link:e}=await fetch(gamesUrl).then(a=>a.json()),t=r.hadiah(h.hadiah),i=Date.now(),s=`*LANJUT SOAL BERIKUTNYA*

Soal: ${r.texted("monospace","Bendera negara apa ini?")}
${global.db.users[n.sender].premium?"\nPetunjuk: "+r.texted("monospace",a.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi,"-")):""}
Hadiah: $${t} balance
Waktu: ${h.gamewaktu} detik`;player=0,database[n.chat]={id:i,chat:await d.sendMessageModify(n.chat,s,n,{thumbUrl:e,largeThumb:!0,title:"GAME TEBAK NEGARA",body:"",expiration:n.expiration}),soal:"Bendera negara manakah itu?",jawaban:a.toLowerCase(),hadiah:t,waktu:setTimeout(async function(){database[n.chat].id==i&&(d.sendMessage(n.chat,{text:`Waktu habis!

Jawabannya adalah: `+r.texted("monospace",a)},{quoted:database[n.chat].chat,ephemeralExpiration:n.expiration}),delete database[n.chat])},1e3*h.gamewaktu)}}},1e3)):/conversation|extendedTextMessage/.test(n.mtype)&&await d.sendMessage(n.chat,{react:{text:"❌",key:n.key}}))}};