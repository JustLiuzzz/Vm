//CREATE BY REZA DEVS KUROMI
let similarity=require("similarity"),gamesUrl="https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/tebakkimia.json",sensitive=.75,database={},player=0;exports.run={usage:["tebakkimia"],hidden:["tkimia"],category:"games",async:async(a,{func:e,kuromi:t,setting:i})=>{if(e.ceklimit(a.sender,1))return a.reply(global.mess.limit);if(a.chat in database)return t.reply(a.chat,"Masih ada soal belum terjawab di chat ini",database[a.chat].chat);let{soal:s,jawaban:n}=(await fetch(gamesUrl).then(a=>a.json())).result.random(),r=e.hadiah(i.hadiah),d=Date.now(),h=`*G A M E - T E B A K K I M I A*

${e.texted("monospace","Apa Nama Unsur "+s+"?")}
Hadiah: $${r} balance
Waktu: ${i.gamewaktu} detik`;player=0,database[a.chat]={id:d,chat:await t.reply(a.chat,h,a,{expiration:a.expiration}),soal:s,jawaban:n.toLowerCase(),hadiah:r,waktu:setTimeout(function(){database[a.chat]?.id==d&&(t.reply(a.chat,`Waktu habis!

Jawabannya adalah: `+e.texted("monospace",n),database[a.chat].chat,{expiration:a.expiration}),delete database[a.chat])},1e3*i.gamewaktu)}},main:async(s,{func:n,kuromi:r,setting:d})=>{var a,e,t,i;s.chat in database&&!s.fromMe&&!s.isPrefix&&({soal:a,jawaban:e,hadiah:t,waktu:i}=database[s.chat],similarity(e,s.budy.toLowerCase())>=sensitive?(player++,await r.sendReact(s.chat,"✅",s.key),global.db.users[s.sender].balance+=t,global.db.users[s.sender].game.tebakkimia+=1,clearTimeout(i),delete database[s.chat],setTimeout(async()=>{if(!(1<player)){if(global.db.users[s.sender].limit<1)return s.reply("Soal dihentikan karena limit kamu sudah habis.");--global.db.users[s.sender].limit;let a=(await fetch(gamesUrl).then(a=>a.json())).result.random(),e=n.hadiah(d.hadiah),t=Date.now(),i=`*LANJUT SOAL BERIKUTNYA*

${n.texted("monospace","Apa Nama Unsur "+a.soal+"?")}
Hadiah: $${e} balance
Waktu: ${d.gamewaktu} detik`;player=0,database[s.chat]={id:t,chat:await r.reply(s.chat,i,s,{expiration:s.expiration}),soal:a.soal,jawaban:a.jawaban.toLowerCase(),hadiah:e,waktu:setTimeout(function(){database[s.chat]?.id==t&&(r.reply(s.chat,`Waktu habis!

Jawabannya adalah: `+n.texted("monospace",a.jawaban),database[s.chat].chat,{expiration:s.expiration}),delete database[s.chat])},1e3*d.gamewaktu)}}},1e3)):/conversation|extendedTextMessage/.test(s.mtype)&&await r.sendReact(s.chat,"❌",s.key))}};