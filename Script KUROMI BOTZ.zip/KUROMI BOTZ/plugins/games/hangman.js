//CREATE BY REZA DEVS KUROMI
let fetch=require("node-fetch"),gamesUrl="https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/tebakkata.json";class HangmanGame{constructor(e){this.sessionId=e,this.guesses=[],this.maxAttempts=0,this.currentStage=0}getRandomQuest=async()=>{try{var{soal:e,jawaban:a}=(await fetch(gamesUrl).then(e=>e.json())).result.random();return{clue:e,quest:a.toLowerCase()}}catch(e){throw console.error("Error fetching random quest:",e),new Error("Failed to fetch a random quest.")}};initializeGame=async()=>{try{this.quest=await this.getRandomQuest(),this.maxAttempts=this.quest.quest.length}catch(e){throw console.error("Error initializing game:",e),new Error("Failed to initialize the game.")}};displayBoard=()=>{var e=["😐","😕","😟","😧","😢","😨","😵"];return(`*Current Stage:* ${e[this.currentStage]}
%==========
||
|   ${e[this.currentStage]}
|   ${3<=this.currentStage?"/":""}${4<=this.currentStage?"|":""}${5<=this.currentStage?"\\":""}
|   ${1<=this.currentStage?"/":""}${2<=this.currentStage?"\\":""}
|
|
==========%
*Clue:* `+this.quest.clue).replaceAll("%","```")};displayWord=()=>this.quest.quest.split("").map(e=>this.guesses.includes(e)?""+e:"__").join(" ");makeGuess=e=>this.isAlphabet(e)?(e=e.toLowerCase(),this.guesses.includes(e)?"repeat":(this.guesses.push(e),this.quest.quest.includes(e)||(this.currentStage=Math.min(this.quest.quest.length,this.currentStage+1)),this.checkGameOver()?"over":this.checkGameWin()?"win":"continue")):"invalid";isAlphabet=e=>/^[a-zA-Z]$/.test(e);checkGameOver=()=>this.currentStage>=this.maxAttempts;checkGameWin=()=>[...new Set(this.quest.quest)].every(e=>this.guesses.includes(e));getHint=()=>"*Hint:* "+this.quest.quest}exports.run={usage:["hangman"],hidden:["hm"],use:"options",category:"games",async:async(e,{kuromi:a})=>{a.hangman=a.hangman||{};var t,s,[n,r]=e.args;try{switch(n){case"end":a.hangman[e.chat]&&a.hangman[e.chat].sessionId===e.sender?(delete a.hangman[e.chat],await e.reply("Successfully exit Hangman session. 👋")):await e.reply("There is no Hangman session in progress or you are not the player.");break;case"start":a.hangman[e.chat]?await e.reply(`The Hangman session is already underway. Use ${e.prefix}hangman *end* to end the session.`):(a.hangman[e.chat]=new HangmanGame(e.sender),await(t=a.hangman[e.chat]).initializeGame(),await e.reply(`Hangman session begins. 🎉

*Session ID:* ${t.sessionId}
${t.displayBoard()}

*Guess the Word:*
${t.displayWord()}

Send letter to guess, example: *${e.prefix}hangman guess a*`));break;case"guess":if(a.hangman[e.chat]){if(!r||!/^[a-zA-Z]$/.test(r))return void await e.reply(`Enter the letter you want to guess after *guess*. Example: *${e.prefix}hangman guess a*`);var i=a.hangman[e.chat],h=r.toLowerCase(),o=i.makeGuess(h),g={invalid:"Masukkan surat yang valid.",repeat:"Anda sudah menebak surat ini sebelumnya. Coba surat yang lain.",continue:`*Tebak Huruf:*
${i.guesses.join(", ")}
${i.displayBoard()}

*Tebak Kata:*
${i.displayWord()}
 
*Percobaan Tersisa:* `+(i.maxAttempts-i.currentStage),over:`Permainan telah berakhir! Kamu kalah. Kata yang benar adalah *${i.quest.quest}*. 💀`,win:"Selamat! Anda menang dalam permainan Hangman. 🎉"};await e.reply(""+g[o]),"over"!==o&&"win"!==o||delete a.hangman[e.chat]}else await e.reply("There are no Hangman sessions in progress. Use *start* to start the session.");break;case"hint":a.hangman[e.chat]?(s=a.hangman[e.chat],await e.reply(s.getHint())):await e.reply("There are no Hangman sessions in progress. Use *start* to start the session.");break;case"help":await e.reply(`*H A N G M A N - G A M E S*

*Commands:*
- *${e.prefix}hangman start :* Starts the Hangman game.
- *${e.prefix}hangman end :* Exits the game session.
- *${e.prefix}hangman guess [letter] :* Guess the letter in a word.
- *${e.prefix}hangman hint :* Get a word clue.`);break;default:await e.reply(`Invalid action. Use ${e.prefix}hangman *help* to see how to use the command.`)}}catch(a){console.error("Error in hangman handler:",a),await e.reply("An error occurred in handling the Hangman game. Please try again.")}}};