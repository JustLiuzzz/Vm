// CREATE BY REZA DEVS KUROMI
exports.run = {
  usage: ['cekgroup'],
  hidden: ['cekgrup'],
  use: 'Cek sisa waktu sebelum bot keluar dari grup jika belum sewa.',
  category: 'group',
  async: async (m, { func, kuromi, isPrem }) => {
    try {
      const db = global.db.groups[m.chat] ||= {}; // Gunakan atau buat objek jika belum ada
      const now = Date.now();

      const sewa = db.sewa || {}; // Ambil data sewa, jika ada
      const isSewa = sewa.status && (sewa.expired === 'PERMANENT' || now < sewa.expired);

      // Cek jika status sewa aktif
      if (isSewa) {
        const expired = sewa.expired === 'PERMANENT' ? 'PERMANEN' : func.toTime(sewa.expired - now);
        return m.reply(`Status Sewa Grup: AKTIF\nSisa Waktu: ${expired}`);
      }

      // Cek jika grup dalam masa trial dan belum disewa
      db.joinedAt ||= now; // Jika belum ada waktu join, set waktu sekarang
      const timeLeft = 2 * 60 * 60 * 1000 - (now - db.joinedAt); // Trial selama 2 jam

      if (timeLeft <= 0) {
        return m.reply(`Bot akan keluar SEGERA karena masa trial sudah habis dan belum disewa.`);
      }

      return m.reply(`Status Sewa Grup: TIDAK AKTIF\nSisa Waktu Trial: ${func.toTime(timeLeft)}`);
    } catch (e) {
      return m.reply(`Terjadi kesalahan: ${e.message}`);
    }
  },
  location: "plugins/group/cekgroup.js"
};