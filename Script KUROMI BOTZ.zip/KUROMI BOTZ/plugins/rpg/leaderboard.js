//CREATE BY REZA DEVS KUROMI
let areJidsSameUser=require("@whiskeysockets/baileys").areJidsSameUser,leaderboards=["level","exp","limit","money","iron","gold","diamond","emerald","trash","potion","petFood","wood","rock","string","common","uncommon","mythic","legendary","pet"];function sort(r,a=!0){return r?(...e)=>e[1&a][r]-e[1&!a][r]:(...e)=>e[1&a]-e[1&!a]}function isNumber(e){return e&&"number"==typeof(e=parseInt(e))&&!isNaN(e)}function toNumber(t,i=0){return t?(e,r,a)=>({...a[r],[t]:void 0===e[t]?i:e[t]}):e=>void 0===e?i:e}function enumGetKey(e){return e.jid}exports.run={usage:["leaderboard"],hidden:["lb"],use:"[type] [page]",category:"rpg",async:async(a,{func:e,kuromi:r})=>{let t=Object.entries(global.db.users).map(([e,r])=>({...r,jid:e}));var i=leaderboards.filter(r=>r&&!r.includes("@g.us")&&t.filter(e=>e&&e[r]).length);let s=(a.args[0]||"").toLowerCase(),o=r=>Math.ceil(t.filter(e=>e&&e[r]).length/25),n=(`Use format *${a.cmd} [type] [page]*
Example: *${a.cmd} money 1*

Type list :
`+i.map(e=>"- "+e).join("\n")).trim();if(!i.includes(s))return a.reply(n);Object.values(global.db.users).filter(e=>e.premium).map(e=>e.jid);var i=isNumber(a.args[1])?Math.min(Math.max(parseInt(a.args[1]),0),o(s)):0,l=(n=t.map(toNumber(s)).sort(sort(s))).map(enumGetKey),e=`*${e.toFirstCase(s)} Leaderboard page ${i} of ${o(s)}*
You: *${l.indexOf(a.sender)+1}* of *${l.length}*

${await n.slice(25*i,25*i+25).filter(e=>e.register).map((r,e)=>`*${e+1}.* ${(a.isGc?a.members.some(e=>areJidsSameUser(r.jid,e.id)):Object.values(global.db.users).filter(e=>e.register).some(e=>areJidsSameUser(r.jid,e.jid)))?""+global.db.users[r.jid].name.replaceAll("\n"," "):"@"+r.jid.split("@")[0]} => *${r[s]} ${s}*`).join`\n`}
`.trim();await r.reply(a.chat,e,a)},register:!0};