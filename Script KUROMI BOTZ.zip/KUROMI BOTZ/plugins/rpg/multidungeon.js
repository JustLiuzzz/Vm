exports.run = {
  usage: ['multidungeon', 'party'],
  hidden: ['raid'],
  use: 'Bergabung dengan dungeon dan berpartisipasi dalam raid bersama teman-teman!',
  category: 'rpg',
  async: async (m, { func, users, group }) => {
    const cooldown = 4 * 60 * 60 * 1000 // 4 jam cooldown
    const now = Date.now()

    // Mengecek apakah pemain dalam dungeon
    if (users.lastDungeon && now - users.lastDungeon < cooldown) {
      const sisa = cooldown - (now - users.lastDungeon)
      return m.reply(`Kamu baru saja masuk dungeon.\nTunggu *${func.clockString(sisa)}* lagi.`)
    }

    // Menyimpan waktu terakhir masuk dungeon
    users.lastDungeon = now

    // Menentukan dungeon
    const dungeonList = ['Dungeon Hutan', 'Kuil Terlarang', 'Reruntuhan Kuno', 'Menara Naga']
    const dungeonChoice = func.pickRandom(dungeonList)

    // Menyusun langkah-langkah dungeon
    const steps = [
      `Kamu masuk ke *${dungeonChoice}* bersama teman-temanmu...`,
      `Suasana sangat gelap dan mencekam...`,
      `Kamu mulai menjelajahi dungeon bersama teman-temanmu...`,
      `Tiba-tiba, kamu menemukan sebuah monster besar!`
    ]
    
    // Kirim langkah-langkah dungeon dengan delay
    for (let i = 0; i < steps.length; i++) {
      await m.reply(steps[i])
      await func.delay(5000) // delay 5 detik
    }

    // Fitur untuk memilih apakah kamu ingin lanjut, berhenti, atau logout
    const choices = ['Lanjutkan Dungeon', 'Berhenti', 'Logout']

    const userChoice = await func.selectOption(m, choices)
    
    if (userChoice === 'Lanjutkan Dungeon') {
      const monster = func.pickRandom(['Goblin', 'Orc', 'Troll', 'Vampir'])
      const reward = Math.floor(Math.random() * 10000) + 5000
      users.balance += reward
      return m.reply(`Kamu melanjutkan dungeon dan mengalahkan *${monster}*!\nHadiah: ${func.formatRupiah ? func.formatRupiah(reward) : reward}`)
    }

    if (userChoice === 'Berhenti') {
      return m.reply('Kamu memutuskan untuk berhenti dan keluar dari dungeon.')
    }

    if (userChoice === 'Logout') {
      return m.reply('Kamu keluar dari dungeon dan logout.')
    }
  },
  group: true,
  location: 'plugins/rpg/multidungeon'
}