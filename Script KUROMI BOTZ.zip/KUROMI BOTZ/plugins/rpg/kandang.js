//CREATE BY REZA DEVS KUROMI
exports.run={usage:["kandang"],category:"rpg",async:async(a,{kuromi:e})=>{var n=`乂  *R P G - K A N D A N G*

*🐂 : ${(n=global.db.users[a.sender]).banteng} banteng*
*🐅 : ${n.harimau} harimau*
*🐘 : ${n.gajah} gajah*
*🐐 : ${n.kambing} kambing*
*🐼 : ${n.panda} panda*
*🐊 : ${n.buaya} buaya*
*🐃 : ${n.kerbau} kerbau*
*🐮 : ${n.sapi} sapi*
*🐒 : ${n.monyet} monyet*
*🐗 : ${n.babihutan} babihutan*
*🐖 : ${n.babi} babi*
*🐓 : ${n.ayam} ayam*

Gunakan *${a.prefix}sell* untuk dijual atau *${a.prefix}cook* untuk dijadikan bahan masakan.`;await e.sendMessageModify(a.chat,n,a,{title:global.header,body:global.footer,thumbUrl:"https://telegra.ph/file/295a6d5105771875e1797.jpg",largeThumb:!0,expiration:a.expiration})},register:!0};