//CREATE BY REZA DEVS KUROMI
let cooldown=9e5;function ranNumb(e,n=null){return null!==n?(e=Math.ceil(e),n=Math.floor(n),Math.floor(Math.random()*(n-e+1))+e):Math.floor(Math.random()*e)+1}exports.run={usage:["adventure"],hidden:["petualang","berpetualang"],category:"rpg",async:async(e,{func:n,kuromi:a,setting:t})=>{var u=global.db.users[e.sender],r=cooldown-(new Date-u.lastadventure);if(u.health<80)return e.reply(`Butuh minimal *❤️ 80 Health* untuk ${e.command}!!

Ketik *${e.prefix}heal* untuk menambah health.
Atau *${e.prefix}use potion* untuk menggunakan potion.`);if(new Date-u.lastadventure<=cooldown)return e.reply(`Kamu sudah berpetualang, mohon tunggu *${n.clockString(r)}*`);u.adventurecount+=1;var n=ranNumb(3,6),r=ranNumb(1e3,3e3),o=ranNumb(500,1e3),l=ranNumb(10,50),d=ranNumb(1,4),m=ranNumb(1,4),c=ranNumb(1,3),i=ranNumb(1,2);u.health-=n,u.money+=r,u.exp+=o,u.trash+=l,u.rock+=d,u.wood+=m,u.string+=c,u.adventurecount%25==0&&(u.common+=i),u.adventurecount%50==0&&(u.gold+=1),u.adventurecount%150==0&&(u.emerald+=1),u.adventurecount%400==0&&(u.diamond+=1);let h=`乂  *RPG - ADVENTURE*

`;h=(h=(h=(h+=`❤️ health *-${n}*
Anda membawa pulang :
`)+`*Money :* ${r}
`+`*Exp :* ${o}
`)+`*Trash :* ${l}
`+`*Rock :* ${d}
`)+`*Wood :* ${m}
`+"*String :* "+c,u.adventurecount%25==0&&(h+=`

Bonus adventure ${u.adventurecount} kali
*Common :* `+i),u.adventurecount%50==0&&(h+=`

Bonus adventure ${u.adventurecount} kali
*Gold :* 1`),u.adventurecount%150==0&&(h+=`

Bonus adventure ${u.adventurecount} kali
*Emerald :* 1`),u.adventurecount%400==0&&(h+=`

Bonus adventure ${u.adventurecount} kali
*Diamond :* 1`),e.reply("_Sedang berpetualang..._"),u.lastadventure=+new Date,setTimeout(()=>{a.reply(e.chat,h,e)},1e3*t.gamewaktu)},register:!0,limit:!0};