exports.run = {
  usage: ['explore'],
  hidden: ['dungeon'],
  use: 'Masuki dungeon untuk menghadapi musuh dan mendapatkan hadiah!',
  category: 'rpg',
  location: 'plugins/rpg/dungeon_exploration.js',
  async: async (m, { func, kuromi, users }) => {
    const cooldown = 2 * 60 * 60 * 1000
    const now = Date.now()

    if (users.lastExplore && now - users.lastExplore < cooldown) {
      const sisa = cooldown - (now - users.lastExplore)
      return m.reply(`Kamu baru saja menjelajahi dungeon. Cobalah lagi dalam *${func.clockString(sisa)}*.`)
    }

    users.lastExplore = now

    const hpUser = users.hp || 100
    if (hpUser <= 0) {
      return m.reply('Kamu tidak memiliki HP yang cukup untuk bertualang. Cobalah untuk menyembuhkan diri terlebih dahulu.')
    }

    const levelDungeon = Math.floor(Math.random() * 5) + 1
    const musuhDungeon = [
      'Goblin', 'Troll', 'Orc', 'Vampire', 'Dragon', 'Zombie', 'Griffin', 'Minotaur', 'Werewolf'
    ]
    const musuhTerpilih = musuhDungeon[Math.floor(Math.random() * musuhDungeon.length)]
    const hpMusuh = Math.floor(Math.random() * 100) + (levelDungeon * 50)
    const damageMusuh = Math.floor(Math.random() * 30) + 10

    let hpAkhirUser = hpUser
    let hpAkhirMusuh = hpMusuh

    let hadiah = 0
    let hasil = ''

    while (hpAkhirUser > 0 && hpAkhirMusuh > 0) {
      hpAkhirMusuh -= Math.floor(Math.random() * 20) + 10
      hpAkhirUser -= damageMusuh

      if (hpAkhirMusuh <= 0) {
        break
      }
    }

    if (hpAkhirMusuh <= 0) {
      hadiah = levelDungeon * 200 + Math.floor(Math.random() * 500)
      hasil = `Selamat! Kamu berhasil mengalahkan *${musuhTerpilih}* di level dungeon ${levelDungeon}!\nKamu mendapatkan +${func.formatRupiah ? func.formatRupiah(hadiah) : hadiah} ke dalam balance kamu!`
      users.balance += hadiah
    } else {
      hasil = `Sayang sekali, kamu kalah melawan *${musuhTerpilih}*.\nCobalah lagi!`
      users.hp -= 10
    }

    return m.reply(
      `───「 *DUNGEON EXPLORATION* 」───\n\n` +
      `Dungeon Level: ${levelDungeon}\n` +
      `Musuh yang kamu hadapi: *${musuhTerpilih}*\n` +
      `HP Musuh: ${hpMusuh}\n` +
      `HP Kamu: ${hpUser}\n\n` +
      `${hasil}`
    )
  }
}