exports.run = {
  usage: ['misi'],
  hidden: ['mission'],
  use: 'Jalankan misi rahasia dan dapatkan hadiah (2 jam sekali)',
  category: 'rpg',
  async: async (m, { func, kuromi, users }) => {
    const cooldown = 2 * 60 * 60 * 1000
    const now = Date.now()

    if (users.lastMission && now - users.lastMission < cooldown) {
      const sisa = cooldown - (now - users.lastMission)
      return m.reply(`Kamu sudah menjalankan misi.\nSilakan coba lagi dalam *${func.clockString(sisa)}*.`)
    }

    const misi = [
      'menyelamatkan desa dari serangan goblin',
      'menembus gua naga untuk mencari artefak kuno',
      'mengawal pedagang melewati hutan gelap',
      'menyelidiki kastil yang ditinggalkan',
      'bertarung di arena gladiator bawah tanah',
      'berlayar ke pulau misterius untuk mencari pusaka',
      'memata-matai markas bandit',
      'mencari bunga langka di puncak gunung bersalju',
      'bertempur melawan raja kegelapan',
      'melarikan diri dari kutukan hutan terlarang',
      'menjinakkan naga liar di lembah sunyi',
      'menghadapi badai pasir untuk menemukan oasis tersembunyi',
      'membuka gerbang rahasia kuil kuno',
      'melawan penyihir jahat yang menguasai desa',
      'menemukan batu ajaib di jurang kematian',
      'membantu roh yang tersesat kembali ke alamnya',
      'menghentikan ritual sesat di reruntuhan kota tua',
      'mengikuti jejak pencuri legenda untuk merebut kembali permata kerajaan',
      'menembus badai es untuk menyelamatkan putri salju',
      'mencuri harta karun dari kapal bajak laut',
      'bertarung melawan siluman dalam kabut hitam',
      'menghadapi turnamen bela diri dunia bawah',
      'menyelidiki misteri desa hilang dalam semalam',
      'bernegosiasi damai dengan bangsa elf di hutan',
      'menghancurkan kristal kegelapan di ruang bawah tanah istana'
    ]

    const cerita = misi[Math.floor(Math.random() * misi.length)]
    const gagal = Math.random() < 0.25

    users.lastMission = now

    if (gagal) {
      return m.reply(`───「 *GAGAL MISI* 」───\n\nKamu mencoba *${cerita}*, namun sayangnya gagal...\nKamu tidak mendapat apapun.`)
    }

    const reward = Math.floor(Math.random() * (3000 - 100 + 1)) + 100
    users.balance += reward

    return m.reply(
      `───「 *MISIMU BERHASIL* 」───\n\n` +
      `Kamu berhasil *${cerita}*!\n` +
      `Hadiah: +${func.formatRupiah ? func.formatRupiah(reward) : reward}`
    )
  }
}