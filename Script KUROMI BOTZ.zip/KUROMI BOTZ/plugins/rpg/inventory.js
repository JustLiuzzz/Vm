//CREATE BY REZA DEVS KUROMI
let daily=864e5,weekly=6048e5,monthly=2592e6,adventure=9e5,inventory={others:{health:!0,money:!0,exp:!0},items:{potion:!0,aqua:!0,petfood:!0,wood:!0,rock:!0,string:!0,iron:!0,trash:!0,botol:!0,kaleng:!0,kardus:!0,emerald:!0,diamond:!0,gold:!0},builds:{rumahsakit:!0,restoran:!0,pabrik:!0,tambang:!0,pelabuhan:!0},crates:{common:!0,uncommon:!0,mythic:!0,legendary:!0},pets:{horse:!0,cat:!0,fox:!0,dog:!0,wolf:!0,centaur:!0,phoenix:!0,dragon:!0},cooks:{steak:!0,sate:!0,rendang:!0,kornet:!0,nugget:!0,bluefin:!0,seafood:!0,sushi:!0,moluska:!0,squidprawm:!0},fruits:{mangga:!0,apel:!0,pisang:!0,jeruk:!0},cooldowns:{lastclaim:{name:"claim",time:daily.cooldown},lastweekly:{name:"weekly",time:weekly.cooldown},lastmonthly:{name:"monthly",time:monthly.cooldown},lastadventure:{name:"adventure",time:adventure.cooldown}}};exports.run={usage:["inventory"],hidden:["inv"],category:"rpg",async:async(e,{func:o,kuromi:t})=>{let r=global.db.users[e.sender];Object.keys(inventory.others).map(e=>r[e]&&o.ucword(e)+" : "+r[e]).filter(e=>e).join("\n").trim();var n=Object.keys(inventory.items).map(e=>r[e]&&o.ucword(e)+" : "+r[e]).filter(e=>e).join("\n").trim(),i=Object.keys(inventory.builds).map(e=>r[e]&&`${o.ucword(e)} : ${r[e]} ( level ${r[e+"lvl"]} )`).filter(e=>e).join("\n").trim(),a=Object.keys(inventory.crates).map(e=>r[e]&&o.ucword(e)+" : "+r[e]).filter(e=>e).join("\n").trim(),s=Object.keys(inventory.pets).map(e=>r[e]&&`${o.ucword(e)} : ${r[e]} ( level ${r[e+"lvl"]} )`).filter(e=>e).join("\n").trim(),l=Object.keys(inventory.cooks).map(e=>r[e]&&o.ucword(e)+" : "+r[e]).filter(e=>e).join("\n").trim(),m=Object.keys(inventory.fruits).map(e=>r[e]&&o.ucword(e)+" : "+r[e]).filter(e=>e).join("\n").trim(),c=Object.entries(inventory.cooldowns).map(([e,{name:t,time:n}])=>e in r&&o.ucword(t)+" : "+(new Date-r[e]>=n?"✅":"❌")).filter(e=>e).join("\n").trim(),n=`Inventory *${t.getName(e.sender)}*

${Object.keys(inventory.others).map(e=>r[e]&&o.ucword(e)+" : "+r[e]).filter(e=>e).join("\n")}${n?`

*I T E M S*
${n}
*Total Items :* ${Object.keys(inventory.items).map(e=>r[e]).reduce((e,t)=>e+t,0)} Items`+o.readmore:""}${i?`

*B U I L D I N G*
${i}
*Total Buldings :* ${Object.keys(inventory.builds).map(e=>r[e]).reduce((e,t)=>e+t,0)} Buildings`:""}${a?`

*C R A T E S*
${a}
*Total Crates :* ${Object.keys(inventory.crates).map(e=>r[e]).reduce((e,t)=>e+t,0)} Boxs`:""}${s?`

*P E T S*
${s}
*Total Pets :* ${Object.keys(inventory.pets).map(e=>r[e]).reduce((e,t)=>e+t,0)} Pets`:""}${l?`

*F O O D S*
${l}
*Total Foods :* ${Object.keys(inventory.cooks).map(e=>r[e]).reduce((e,t)=>e+t,0)} Dish`:""}${m?`

*F R U I T S*
${m}
*Total Fruits :* ${Object.keys(inventory.fruits).map(e=>r[e]).reduce((e,t)=>e+t,0)} Fruits`:""}${c?`

*C O O L D O W N S*
`+c:""}
`.trim();t.reply(e.chat,n,e)},register:!0};