//CREATE BY REZA DEVS KUROMI
let cooldown=432e5,timeout=18e4;exports.run={usage:["mancing"],hidden:["fishing"],category:"rpg",async:async(i,{func:a,kuromi:n,setting:e})=>{let o=global.db.users[i.sender];var r,t=cooldown-(new Date-o.lastfishing);if(new Date-o.lastfishing<=cooldown)return i.reply(`Kamu sudah memancing, mohon tunggu *${a.clockString(t)}*`);if(0==o.fishingrod)return i.reply(`Perlu *${i.prefix}craft* fishingrod terlebih dahulu.

Anda memiliki *${o.fishingrod}* FishingRod`);let k=[{ikan:0},{ikan:0},{ikan:0},{ikan:0},{ikan:0},{ikan:0},{ikan:0},{ikan:0},{ikan:0},{ikan:0},{ikan:0},{ikan:0},{ikan:0}];for(r of k){var l=a.randomNomor(0,100);r.ikan+=l}let g=`乂  *R P G - M A N C I N G*

Hasil tangkapan hari ini :
*🐋 Orca : ${k[0].ikan}* 
*🐳 Paus : ${k[1].ikan}* 
*🐬 Lumba : ${k[2].ikan}* 
*🦈 Hiu : ${k[3].ikan}* 
*🐟 Ikan : ${k[4].ikan}* 
*🐟 Lele : ${k[5].ikan}* 
*🐡 Bawal : ${k[6].ikan}*
*🐠 Nila : ${k[7].ikan}*
*🦀 Kepiting : ${k[8].ikan}*
*🦞 Lobster : ${k[9].ikan}*
*🐙 Gurita : ${k[10].ikan}*
*🦑 Cumi : ${k[11].ikan}*
*🦐 Udang : ${k[12].ikan}*`;o.fishingroddurability-=a.randomNomor(80,120),o.fishingroddurability<=0&&(o.fishingroddurability=0,o.fishingrod=0),i.reply("_Sedang memancing..._"),o.lastfishing=+new Date,o.mancingcount+=1,setTimeout(async()=>{o.orca+=k[0].ikan,o.paus+=k[1].ikan,o.lumba+=k[2].ikan,o.hiu+=k[3].ikan,o.ikan+=k[4].ikan,o.lele+=k[5].ikan,o.bawal+=k[6].ikan,o.nila+=k[7].ikan,o.kepiting+=k[8].ikan,o.lobster+=k[9].ikan,o.gurita+=k[10].ikan,o.cumi+=k[11].ikan,o.udang+=k[12].ikan,await n.sendMessageModify(i.chat,g,i,{title:global.header,body:global.footer,thumbUrl:"https://telegra.ph/file/4a2dad6f0f6dfef650bf3.jpg",largeThumb:!0,expiration:i.expiration})},1e3*e.gamewaktu)},register:!0},exports.cooldown=cooldown;