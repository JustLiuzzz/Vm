//CREATE BY REZA DEVS KUROMI
function ranNumb(e,a=null){return null!==a?(e=Math.ceil(e),a=Math.floor(a),Math.floor(Math.random()*(a-e+1))+e):Math.floor(Math.random()*e)+1}exports.run={usage:["berdagang"],hidden:["dagang"],use:"mention or reply",category:"rpg",async:async(e,{func:a,kuromi:n,froms:t,setting:r})=>{var u=72e5;if(!t)return e.reply("Tag salah satu yang kamu ingin ajak berdagang");if(void 0===global.db.users[t])return e.reply("Pengguna tidak ada didalam database.");let g=global.db.users[e.sender],m=global.db.users[t];if(!m.register)return e.reply("Pengguna tersebut belum terverifikasi.");if(new Date-g.lastdagang<=u)return e.reply(`Kamu sudah berdagang, mohon tunggu *${a.clockString(g.lastdagang+u-new Date)}* lagi.`);if(g.money<1e4)return e.reply("Modal diperlukan, Kamu tidak memiliki 10000 money.");if(new Date-m.lastdagang<=u)return e.reply(`Teman anda sedang berdagang, cari partner lain atau tunggu *${a.clockString(m.lastdagang+u-new Date)}* lagi . . .`);if(m.money<1e4)return e.reply("Modal diperlukan, Rekanmu tidak memiliki 10000 money.");let o;g.money-=1e4,m.money-=1e4,g.lastdagang=+new Date,m.lastdagang=+new Date,n.reply(e.chat,`Mohon bersabar, Kamu dan ${global.db.users[t].name} sedang berdagang..

Modal masing² adalah 10.000 money.`,e),setTimeout(()=>{o=ranNumb(7e3,12e3),g.money+=o,m.money+=o,n.reply(e.chat,`*PENGHASILAN DAGANG*

+${o} money untukmu dan `+n.getName(t),e)},1e3*r.gamewaktu),setTimeout(()=>{o=ranNumb(7e3,12e3),g.money+=o,m.money+=o,n.reply(e.chat,`*PENGHASILAN DAGANG*

+${o} money untukmu dan `+n.getName(t),e)},2e3*r.gamewaktu),setTimeout(()=>{o=ranNumb(7e3,12e3),g.money+=o,m.money+=o,n.reply(e.chat,`*PENGHASILAN DAGANG*

+${o} money untukmu dan `+n.getName(t),e)},3e3*r.gamewaktu),setTimeout(()=>{o=ranNumb(7e3,12e3),g.money+=o,m.money+=o,n.reply(e.chat,`*PENGHASILAN DAGANG*

+${o} money untukmu dan `+n.getName(t),e)},4e3*r.gamewaktu)},group:!0,register:!0,limit:!0},exports.cooldown=cooldown;