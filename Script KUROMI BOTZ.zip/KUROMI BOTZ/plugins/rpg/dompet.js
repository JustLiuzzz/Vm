//CREATE BY REZA DEVS KUROMI
exports.run={usage:["dompet"],category:"rpg",async:async(e,{func:a,kuromi:r,setting:i,fkon:t})=>{var s,l=e.quoted?e.quoted.sender:e.mentionedJid[0]||e.sender;return void 0===global.db.users[l]?e.reply("User tidak ada didalam database."):global.db.users[l].register?(s=global.db.users[l],l=`Dompet @${l.split("@")[0]}

Name: ${s.name.replaceAll("\n","")}
Balance: $${a.rupiah(s.balance)}
Limit: ${s.limit}/${s.premium?1e3:i.limit}
Money: ${a.rupiah(s.money)}
Exp: `+s.exp,void r.reply(e.chat,l,t)):e.reply("Pengguna tersebut belum terverifikasi.")},register:!0};