exports.run = {
  usage: ['judidadu'],
  hidden: ['bet'],
  use: 'Taruh taruhanmu dan lempar dadu untuk memenangkan hadiah!',
  category: 'rpg',
  async: async (m, { func, kuromi, users }) => {
    const cooldown = 2 * 60 * 60 * 1000
    const now = Date.now()

    if (users.lastGamble && now - users.lastGamble < cooldown) {
      const sisa = cooldown - (now - users.lastGamble)
      return m.reply(`Kamu baru saja bermain. Cobalah lagi dalam *${func.clockString(sisa)}*.`)
    }

    const taruhan = parseInt(m.args[0])

    if (isNaN(taruhan) || taruhan <= 0) {
      return m.reply('Masukkan jumlah taruhan yang valid!')
    }

    if (users.balance < taruhan) {
      return m.reply('Kamu tidak memiliki saldo yang cukup untuk bertaruh.')
    }

    const hasilDadu = Math.floor(Math.random() * 6) + 1
    const menang = hasilDadu >= 4 // menang jika dadu 4 atau lebih

    users.lastGamble = now

    if (menang) {
      const reward = taruhan * 2
      users.balance += reward
      return m.reply(
        `───「 *MENANG* 」───\n\n` +
        `Hasil dadu: ${hasilDadu}\n` +
        `Selamat, kamu menang dan mendapatkan +${func.formatRupiah ? func.formatRupiah(reward) : reward}!`
      )
    } else {
      users.balance -= taruhan
      return m.reply(
        `───「 *KALAH* 」───\n\n` +
        `Hasil dadu: ${hasilDadu}\n` +
        `Sayang sekali, kamu kalah dan kehilangan ${func.formatRupiah ? func.formatRupiah(taruhan) : taruhan}.`
      )
    }
  }
}