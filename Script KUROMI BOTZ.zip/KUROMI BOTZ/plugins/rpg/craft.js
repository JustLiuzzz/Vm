//CREATE BY REZA DEVS KUROMI
function isNumber(i){return i&&"number"==typeof(i=parseInt(i))&&!isNaN(i)}exports.run={usage:["craft"],hidden:["crafting"],use:"options",category:"rpg",async:async(i,{kuromi:r})=>{var e=global.db.users[i.sender],a=`乂  *C R A F T I NG - L I S T*

◦ %steel%
◦ %kargo%
◦ %kapal%
◦ %armor%
◦ %sword%
◦ %pickaxe%
◦ %fishingrod%
◦ %bow%

Format: *${i.cmd} [item] [jumlah]*
Contoh: *${i.cmd} armor 2*`,o=(i.args[0]||"").trim().toLowerCase(),t=+Math.floor(isNumber(i.args[1])?Math.min(Math.max(parseInt(i.args[1]),1),Number.MAX_SAFE_INTEGER):1);if(/^(bow|panah)/.test(o))if(0==e.bow){if(e.wood<29||e.string<3||e.iron<1)return i.reply(`Diperlukan 29 wood, 3 string, 1 iron.

Anda memiliki :
- ${e.wood} wood
- ${e.string} string
- ${e.iron} iron`);e.wood-=29,e.string-=3,--e.iron,e.bow+=1,e.bowdurability+=250,e.craftcount+=1,i.reply(`Craft *1 🏹 Bow* Berhasil.

Durability : `+e.bowdurability)}else i.reply(`Anda sudah memiliki 🏹 Bow

Durability : `+e.bowdurability);else if(/^(pancing|fishingrod)/.test(o))if(0==e.fishingrod){if(e.iron<10||e.string<4)return i.reply(`Diperlukan 10 iron, 4 string.

Anda memiliki :
- ${e.iron} iron
- ${e.string} string`);e.iron-=10,e.string-=4,e.fishingrod+=1,e.fishingroddurability+=250,e.craftcount+=1,i.reply(`Craft *1 🎣 Fishingrod* Berhasil.

Durability : `+e.fishingroddurability)}else i.reply(`Anda sudah memiliki 🎣 Fishingrod

Durability : `+e.fishingroddurability);else if(/^(kapak|pickaxe)/.test(o))if(0==e.pickaxe){if(e.iron<12||e.wood<12)return i.reply(`Diperlukan 12 iron, 12 wood.

Anda memiliki :
- ${e.iron} iron
- ${e.wood} wood`);e.iron-=12,e.wood-=12,e.pickaxe+=1,e.pickaxedurability+=250,e.craftcount+=1,i.reply(`Craft *1 ⛏️ pickaxe* Berhasil.

Durability : `+e.pickaxedurability)}else i.reply(`Anda sudah memiliki ⛏️ pickaxe

Durability : `+e.pickaxedurability);else if(/^(pedang|sword)/.test(o))if(0==e.sword){if(e.iron<11||e.steel<4)return i.reply(`Diperlukan 11 iron, 4 steel.

Anda memiliki :
- ${e.iron} iron
- ${e.steel} steel`);e.iron-=11,e.steel-=4,e.sword+=1,e.sworddurability+=250,e.craftcount+=1,i.reply(`Craft *1 ⚔️ sword* Berhasil.

Durability : `+e.sworddurability)}else i.reply(`Anda sudah memiliki ⚔️ sword

Durability : `+e.sworddurability);else if(/^(armor)/.test(o))if(0==e.armor){if(e.steel<2||e.string<4||e.iron<6)return i.reply(`Diperlukan 2 steel, 4 string, 6 iron.

Anda memiliki :
- ${e.steel} steel
- ${e.string} string
- ${e.iron} iron`);e.steel-=2,e.string-=4,e.iron-=6,e.armor+=1,e.armordurability+=250,e.craftcount+=1,i.reply(`Craft *1 🥼 armor* Berhasil.

Durability : `+e.armordurability)}else i.reply(`Anda sudah memiliki 🥼 armor

Durability : `+e.armordurability);else if(/^(baja|steel)/.test(o)){if(e.iron<2*t||e.money<4e3*t)return i.reply(`Diperlukan ${2*t} iron, ${4e3*t} money.

Anda memiliki :
- ${e.iron} iron
- ${e.money} money`);e.iron-=2*t,e.money-=4e3*t,e.steel+=t,e.craftcount+=1,i.reply(`Craft *${t} steel* Berhasil.

Total steel : `+e.steel)}else if(/^(kapal|ship)/.test(o)){if(e.steel<6*t||e.iron<13*t||e.wood<13*t)return i.reply(`Diperlukan ${6*t} steel, ${13*t} iron, ${13*t} wood.

Anda memiliki :
- ${e.steel} steel
- ${e.iron} iron
- ${e.wood} wood`);e.steel-=6*t,e.iron-=13*t,e.wood-=13*t,e.kapal+=t,e.craftcount+=1,i.reply(`Craft *${t} kapal* Berhasil.

Total kapal : `+e.kapal)}else if(/^(kargo|cargo)/.test(o)){if(e.iron<30*t||e.steel<3*t)return i.reply(`Diperlukan ${30*t} iron, ${3*t} steel.

Anda memiliki :
- ${e.iron} iron
- ${e.steel} steel`);e.iron-=30*t,e.steel-=3*t,e.kargo+=t,e.craftcount+=1,i.reply(`Craft *${t} kargo* Berhasil.

Total kargo : `+e.kargo)}else r.reply(i.chat,a.replaceAll("%","```"),i)},register:!0,limit:!0};