exports.run = {
  usage: ['arenabattle'],
  hidden: ['battle'],
  use: 'Bertarung di arena melawan berbagai musuh untuk mendapatkan hadiah!',
  category: 'rpg',
  location: 'plugins/rpg/arena_battle.js',
  async: async (m, { func, kuromi, users }) => {
    const cooldown = 3 * 60 * 60 * 1000
    const now = Date.now()

    if (users.lastBattle && now - users.lastBattle < cooldown) {
      const sisa = cooldown - (now - users.lastBattle)
      return m.reply(`Kamu baru saja bertarung di arena. Cobalah lagi dalam *${func.clockString(sisa)}*.`)
    }

    users.lastBattle = now

    const hpUser = users.hp || 100
    if (hpUser <= 0) {
      return m.reply('Kamu tidak memiliki HP yang cukup untuk bertarung. Cobalah untuk menyembuhkan diri terlebih dahulu.')
    }

    const enemies = [
      'Goblin', 'Troll', 'Orc', 'Vampire', 'Dragon', 'Zombie', 'Griffin', 'Minotaur', 'Werewolf',
      'Mummy', 'Elf', 'Giant', 'Cerberus', 'Wyvern', 'Witch', 'Basilisk', 'Demon', 'Lich', 'Phantom',
      'Harpy', 'Golem', 'Chimera', 'Hydra', 'Kraken', 'Behemoth', 'Phoenix', 'Dark Knight', 'Black Dragon',
      'Dark Elf', 'Succubus', 'Angel', 'Beast', 'Witch King', 'Manticore', 'Shadow Knight', 'Specter',
      'Death Knight', 'Sphinx', 'Valkyrie', 'Giant Spider', 'Cursed Warrior', 'Gorgon', 'Fire Elemental',
      'Ice Elemental', 'Earth Elemental', 'Air Elemental', 'Thunder Elemental', 'Necromancer', 'Black Knight', 
      'Vampire Lord', 'Hellhound', 'Nightmare'
    ]

    const enemyType = enemies[Math.floor(Math.random() * enemies.length)]
    const hpEnemy = Math.floor(Math.random() * 150) + 50  // HP musuh acak antara 50-200
    const damageEnemy = Math.floor(Math.random() * 30) + 10  // Damage musuh acak antara 10-40

    let hpUserFinal = hpUser
    let hpEnemyFinal = hpEnemy

    let hadiah = 0
    let hasil = ''

    while (hpUserFinal > 0 && hpEnemyFinal > 0) {
      hpEnemyFinal -= Math.floor(Math.random() * 30) + 20  // Pengurangan HP musuh
      hpUserFinal -= damageEnemy  // Pengurangan HP pengguna

      if (hpEnemyFinal <= 0) {
        break
      }
    }

    if (hpEnemyFinal <= 0) {
      hadiah = Math.floor(Math.random() * 1000) + 500
      hasil = `Selamat! Kamu berhasil mengalahkan *${enemyType}*!\nKamu mendapatkan +${func.formatRupiah ? func.formatRupiah(hadiah) : hadiah} ke dalam balance kamu!`
      users.balance += hadiah
    } else {
      hasil = `Sayang sekali, kamu kalah melawan *${enemyType}*.\nCobalah lagi setelah memulihkan diri!`
      users.hp -= 10
    }

    return m.reply(
      `───「 *ARENA BATTLE* 」───\n\n` +
      `Lawan: *${enemyType}*\n` +
      `HP Musuh: ${hpEnemy}\n` +
      `HP Kamu: ${hpUser}\n\n` +
      `${hasil}`
    )
  }
}