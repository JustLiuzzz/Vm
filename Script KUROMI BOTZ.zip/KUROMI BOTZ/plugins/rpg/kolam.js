//CREATE BY REZA DEVS KUROMI
exports.run={usage:["kolam"],category:"rpg",async:async(a,{kuromi:e})=>{var i=`乂  *R P G - K O L A M*

*🐋 = ${(i=global.db.users[a.sender]).orca} orca*
*🐳 = ${i.paus} paus*
*🐬 = ${i.lumba} lumba*
*🦈 = ${i.hiu} hiu*
*🐟 = ${i.ikan} ikan*
*🐟 = ${i.lele} lele*
*🐡 = ${i.bawal} bawal*
*🐠 = ${i.nila} nila*
*🦀 = ${i.kepiting} kepiting*
*🦞 = ${i.lobster} lobster*
*🐙 = ${i.gurita} gurita*
*🦑 = ${i.cumi} cumi*
*🦐 = ${i.udang} udang*

Gunakan *${a.prefix}sell* untuk dijual atau *${a.prefix}cook* untuk dijadikan bahan masakan.`;await e.sendMessageModify(a.chat,i,a,{title:global.header,body:global.footer,thumbUrl:"https://telegra.ph/file/4a2dad6f0f6dfef650bf3.jpg",largeThumb:!0,expiration:a.expiration})},register:!0};