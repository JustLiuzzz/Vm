//CREATE BY REZA DEVS KUROMI
exports.run={usage:["open"],hidden:["buka"],use:"[crate] [count]",category:"rpg",async:async(e,{func:r})=>{let a=global.db.users[e.sender],t=(e.args[0]||"").toLowerCase(),c=+Math.floor(r.isNumber(e.args[1])?Math.min(Math.max(parseInt(e.args[1]),1),Number.MAX_SAFE_INTEGER):1);if(a[t]<c)return e.reply(`Kamu tidak memiliki *${t} crate*.`);if(a[t]<c)return e.reply(`Kamu hanya memiliki ${a[t]} ${t} crate* untuk dibuka.`);if(100<c&&(c=100),r.somematch(["common","uncommon","mythic","legendary","petbox"],t))if("common"==t){let m=0,n=0;var d=r.randomNomor(2e3,5e3),u=r.randomNomor(175,225),i=r.randomNomor(10,30),l=r.randomNomor(1,3);a.money+=d*c,a.exp+=u*c,a.trash+=i*c,a.potion+=l*c;for(let o=1;o<=c;o++)a.commoncount+=1,a.commoncount%10==0&&(a.common+=1,m+=1),a.commoncount%20==0&&(a.uncommon+=1,n+=1);a.common-=c;let o=`Kamu membuka *${c} ${t} crate* dan mendapatkan :
`;o=(o=(o=(o+=d*c+` money
`)+u*c+` exp
`)+i*c+` trash
`)+l*c+" potion",0!=m&&(o+=`
Bonus : common')} *${m} common*`),0!=n&&(o+=`
Bonus : uncommon')} *${n} uncommon*`),e.reply(o)}else if("uncommon"==t){let m=0,n=0;var d=r.randomNomor(2e3,5e3),u=r.randomNomor(275,325),i=r.randomNomor(10,30),l=r.randomNomor(1,3),s=r.randomNomor(1,3),y=r.randomNomor(1,3),p=r.randomNomor(1,3);a.money+=d*c,a.exp+=u*c,a.trash+=i*c,a.potion+=l*c,a.wood+=s*c,a.rock+=y*c,a.string+=p*c;for(let o=1;o<=c;o++)a.uncommoncount+=1,a.uncommoncount%10==0&&(a.uncommon+=1,m+=1),a.uncommoncount%20==0&&(a.mythic+=1,n+=1);a.uncommon-=c;let o=`Kamu membuka *${c} ${t} crate* dan mendapatkan :
`;o=(o=(o=(o=(o=(o=(o+=d*c+` money
`)+u*c+` exp
`)+i*c+` trash
`)+l*c+` potion
`)+s*c+` wood
`)+y*c+` rock
`)+p*c+" string",0!=m&&(o+=`
Bonus : uncommon')} *${m} uncommon*`),0!=n&&(o+=`
Bonus : mythic')} *${n} mythic*`),e.reply(o)}else if("mythic"==t){let m=0,n=0;var d=r.randomNomor(2e3,5e3),u=r.randomNomor(300,400),i=r.randomNomor(10,30),l=r.randomNomor(1,3),s=r.randomNomor(1,3),y=r.randomNomor(1,3),p=r.randomNomor(1,3),N=r.randomNomor(1,3);a.money+=d*c,a.exp+=u*c,a.trash+=i*c,a.potion+=l*c,a.wood+=s*c,a.rock+=y*c,a.string+=p*c,a.steel+=N*c;for(let o=1;o<=c;o++)a.mythiccount+=1,a.mythiccount%10==0&&(a.mythic+=1,m+=1),a.mythiccount%20==0&&(a.legendary+=1,n+=1);a.mythic-=c;let o=`Kamu membuka *${c} ${t} crate* dan mendapatkan :
`;o=(o=(o=(o=(o=(o=(o=(o+=d*c+` money
`)+u*c+` exp
`)+i*c+` trash
`)+l*c+` potion
`)+s*c+` wood
`)+y*c+` rock
`)+p*c+` string
`)+N*c+" steel",0!=m&&(o+=`
Bonus : mythic')} *${m} mythic*`),0!=n&&(o+=`
Bonus : legendary')} *${n} legendary*`),e.reply(o)}else if("legendary"==t){let m=0,n=0;d=r.randomNomor(15e3,2e4),u=r.randomNomor(375,475),i=r.randomNomor(10,30),l=r.randomNomor(1,3),s=r.randomNomor(1,3),y=r.randomNomor(1,3),p=r.randomNomor(1,3),N=r.randomNomor(1,3),a.money+=d*c,a.exp+=u*c,a.trash+=i*c,a.potion+=l*c,a.wood+=s*c,a.rock+=y*c,a.string+=p*c,a.steel+=N*c;for(let o=1;o<=c;o++)a.legendarycount+=1,a.legendarycount%10==0&&(a.legendary+=1,m+=1),a.legendarycount%20==0&&(a.pet+=1,n+=1);a.legendary-=c;let o=`Kamu membuka *${c} ${t} crate* dan mendapatkan :
`;o=(o=(o=(o=(o=(o=(o=(o+=d*c+` money
`)+u*c+` exp
`)+i*c+` trash
`)+l*c+` potion
`)+s*c+` wood
`)+y*c+` rock
`)+p*c+` string
`)+N*c+" rock",0!=m&&(o+=`
Bonus : legendary')} *${m} legendary*`),0!=n&&(o+=`
Bonus : pet')} *${n} petbox*`),e.reply(o)}else e.reply(`Comming soon :
*${e.prefix}pet*
*${e.prefix}petbattle*`);else e.reply(`Use Format *${e.cmd} [crate] [count]*
Usage example: *${e.cmd} common 10*

CRATE LIST :
common
uncommon
mythic
legendary
petbox`)},register:!0};