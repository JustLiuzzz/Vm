//CREATE BY REZA DEVS KUROMI
let cooldown=12e5,timeout=3e5;function isNumber(a){return a&&"number"==typeof(a=parseInt(a))&&!isNaN(a)}exports.run={usage:["cook"],hidden:["cooking","masak","memasak"],use:"[item] [count]",category:"rpg",async:async(a,{func:e,kuromi:i})=>{let s=global.db.users[a.sender],m=`乂  *C O O K I N G - L I S T*

%🍝 steak%
%🍢 sate%
%🍜 rendang%
%🥣 kornet%
%🍱 nugget%
%🍲 bluefin%
%🍛 seafood%
%🥘 moluska%
%🍣 sushi%
%🍤 squidprawm%

Format: *${a.cmd} [item] [jumlah]*
Contoh: *${a.cmd} rendang 2*`,n=(a.args[0]||"").toLowerCase(),t=+Math.floor(isNumber(a.args[1])?Math.min(Math.max(parseInt(a.args[1]),1),Number.MAX_SAFE_INTEGER):1);if(new Date-s.lastmasak<=cooldown)return a.reply(`Kamu sudah memasak, mohon tunggu *${e.clockString(s.lastmasak-new Date)}*`);"steak"==n?s.panda<t||s.ayam<t||s.kerbau<t||s.bawang<33*t||s.saus<43*t?a.reply(`Diperlukan ${t} panda, ${t} ayam, ${t} kerbau, ${33*t} bawang, ${43*t} saus.

Anda memiliki :
- ${s.panda} panda
- ${s.ayam} ayam
- ${s.kerbau} kerbau
- ${s.bawang} bawang
- ${s.saus} saus`):(s.lastmasak=+new Date+cooldown*t,setTimeout(()=>{s.panda-=t,s.ayam-=t,s.kerbau-=t,s.bawang-=33*t,s.saus-=43*t,s.steak+=t,s.masakcount+=1,a.reply(`Anda memasak *${t} steak*.

Total steak : `+s.steak)},timeout/30)):"sate"==n?s.harimau<t||s.babihutan<t||s.sapi<t||s.bawang<33*t||s.saus<43*t?a.reply(`Diperlukan ${t} harimau, ${t} babihutan, ${t} sapi, ${33*t} bawang, ${43*t} saus.

Anda memiliki :
- ${s.harimau} harimau
- ${s.babihutan} babihutan
- ${s.sapi} sapi
- ${s.bawang} bawang
- ${s.saus} saus`):(s.lastmasak=+new Date+cooldown*t,setTimeout(()=>{s.harimau-=t,s.babihutan-=t,s.sapi-=t,s.bawang-=33*t,s.saus-=43*t,s.sate+=t,s.masakcount+=1,a.reply(`Anda memasak *${t} sate*.

Total sate : `+s.sate)},timeout/30)):"rendang"==n?s.gajah<t||s.buaya<t||s.bawang<27*t||s.cabai<16*t||s.jahe<30*t?a.reply(`Diperlukan ${t} gajah, ${t} buaya, ${27*t} bawang, ${16*t} cabai, ${30*t} jahe.

Anda memiliki :
- ${s.gajah} gajah
- ${s.buaya} buaya
- ${s.bawang} bawang
- ${s.cabai} cabai, 
- ${s.jahe} jahe`):(s.lastmasak=+new Date+cooldown*t,setTimeout(()=>{s.gajah-=t,s.buaya-=t,s.bawang-=27*t,s.cabai-=16*t,s.jahe-=30*t,s.rendang+=t,s.masakcount+=1,a.reply(`Anda memasak *${t} rendang*.

Total rendang : `+s.rendang)},timeout/30)):"kornet"==n?s.kambing<t||s.monyet<t||s.saus<72*t||s.asam<80*t||s.kemiri<40*t?a.reply(`Diperlukan ${t} kambing, ${t} monyet, ${72*t} saus, ${80*t} asam, ${40*t} kemiri.

Anda memiliki :
- ${s.kambing} kambing
- ${s.monyet} monyet
- ${s.saus} saus
- ${s.asam} asam
- ${s.kemiri} kemiri`):(s.lastmasak=+new Date+cooldown*t,setTimeout(()=>{s.kambing-=t,s.monyet-=t,s.saus-=72*t,s.asam-=80*t,s.kemiri-=40*t,s.kornet+=t,s.masakcount+=1,a.reply(`Anda memasak *${t} kornet*.

Total kornet : `+s.kornet)},timeout/30)):"nugget"==n?s.banteng<t||s.babi<t||s.saus<72*t||s.bawang<34*t||s.kemiri<50*t?a.reply(`Diperlukan ${t} banteng, ${t} babi, ${72*t} saus, ${34*t} bawang, ${50*t} kemiri.

Anda memiliki :
- ${s.banteng} banteng
- ${s.babi} babi
- ${s.saus} saus
- ${s.bawang} bawang, 
- ${s.kemiri} kemiri`):(s.lastmasak=+new Date+cooldown*t,setTimeout(()=>{s.banteng-=t,s.babi-=t,s.saus-=72*t,s.bawang-=34*t,s.kemiri-=50*t,s.nugget+=t,s.masakcount+=1,a.reply(`Anda memasak *${t} nugget*.

Total nugget : `+s.nugget)},timeout/30)):"sushi"==n?s.lobster<2*t||s.hiu<3*t||s.bawal<3*t||s.asam<60*t||s.kemiri<30*t?a.reply(`Diperlukan ${2*t} lobster, ${3*t} hiu, ${3*t} bawal, ${60*t} asam, ${30*t} kemiri.

Anda memiliki :
- ${s.lobster} lobster
- ${s.hiu} hiu
- ${s.bawal} bawal
- ${s.asam} asam, 
- ${s.kemiri} kemiri`):(s.lastmasak=+new Date+cooldown*t,setTimeout(()=>{s.lobster-=2*t,s.hiu-=3*t,s.bawal-=3*t,s.asam-=60*t,s.kemiri-=30*t,s.sushi+=t,s.masakcount+=1,a.reply(`Anda memasak *${t} sushi*.

Total sushi : `+s.sushi)},timeout/30)):"moluska"==n?s.udang<3*t||s.cumi<3*t||s.lele<5*t||s.saus<54*t||s.asam<75*t?a.reply(`Diperlukan ${3*t} udang, ${3*t} cumi, ${5*t} lele, ${54*t} saus, ${75*t} asam.

Anda memiliki :
- ${s.udang} udang
- ${s.cumi} cumi
- ${s.lele} lele
- ${s.saus} saus, 
- ${s.asam} asam`):(s.lastmasak=+new Date+cooldown*t,setTimeout(()=>{s.udang-=3*t,s.cumi-=3*t,s.lele-=5*t,s.saus-=54*t,s.asam-=75*t,s.moluska+=t,s.masakcount+=1,a.reply(`Anda memasak *${t} moluska*.

Total moluska : `+s.moluska)},timeout/30)):"squidprawm"==n?s.kepiting<2*t||s.lumba<3*t||s.gurita<7*t||s.bawang<26*t||s.asam<71*t?a.reply(`Diperlukan ${2*t} kepiting, ${3*t} lumba, ${7*t} gurita, ${26*t} bawang, ${71*t} asam.

Anda memiliki :
- ${s.kepiting} kepiting
- ${s.lumba} lumba
- ${s.gurita} gurita
- ${s.bawang} bawang, 
- ${s.asam} asam`):(s.lastmasak=+new Date+cooldown*t,setTimeout(()=>{s.kepiting-=2*t,s.lumba-=3*t,s.gurita-=7*t,s.bawang-=26*t,s.asam-=71*t,s.squidprawm+=t,s.masakcount+=1,a.reply(`Anda memasak *${t} squidprawm*.

Total squidprawm : `+s.squidprawm)},timeout/30)):"bluefin"==n?s.paus<t||s.ikan<2*t||s.kemiri<50*t||s.cabai<20*t?a.reply(`Diperlukan ${t} paus, ${2*t} ikan, ${50*t} kemiri, ${20*t} cabai.

Anda memiliki :
- ${s.paus} paus
- ${s.ikan} ikan
- ${s.kemiri} kemiri, 
- ${s.cabai} cabai`):(s.lastmasak=+new Date+cooldown*t,setTimeout(()=>{s.paus-=t,s.ikan-=2*t,s.kemiri-=50*t,s.cabai-=20*t,s.bluefin+=t,s.masakcount+=1,a.reply(`Anda memasak *${t} bluefin*.

Total bluefin : `+s.bluefin)},timeout/30)):"seafood"==n?s.orca<t||s.nila<10*t||s.kemiri<50*t||s.cabai<20*t?a.reply(`Diperlukan ${t} orca, ${10*t} nila, ${50*t} kemiri, ${20*t} cabai.

Anda memiliki :
- ${s.orca} orca
- ${s.nila} nila
- ${s.kemiri} kemiri, 
- ${s.cabai} cabai`):(s.lastmasak=+new Date+cooldown*t,setTimeout(()=>{s.orca-=t,s.nila-=10*t,s.kemiri-=50*t,s.cabai-=20*t,s.seafood+=t,s.masakcount+=1,a.reply(`Anda memasak *${t} seafood*.

Total seafood : `+s.seafood)},timeout/30)):i.reply(a.chat,m.replaceAll("%","```"),a)},register:!0,limit:!0};