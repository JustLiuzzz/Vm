//CREATE BY REZA DEVS KUROMI
exports.run={usage:["listbuah"],hidden:["buah"],category:"rpg",async:async(a,{kuromi:e})=>{var n=`乂  *L I S T - B U A H*

🍌 ${(n=global.db.users[a.sender]).pisang} Pisang
🍇 ${n.anggur} Anggur
🥭 ${n.mangga} Mangga
🍊 ${n.jeruk} Jeruk
🍎 ${n.apel} Apel

Gunakan command *${a.prefix}sell* untuk menjual.`;e.reply(a.chat,n,a)},register:!0};