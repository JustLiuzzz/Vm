exports.run = {
  usage: ['roda'],
  hidden: ['luckywheel'],
  use: 'Putar roda keberuntungan dan dapatkan hadiah atau kehilangan saldo!',
  category: 'rpg',
  async: async (m, { func, kuromi, users }) => {
    const cooldown = 2 * 60 * 60 * 1000
    const now = Date.now()

    if (users.lastWheel && now - users.lastWheel < cooldown) {
      const sisa = cooldown - (now - users.lastWheel)
      return m.reply(`Kamu baru saja memutar roda. Cobalah lagi dalam *${func.clockString(sisa)}*.`)
    }

    const taruhan = parseInt(m.args[0])

    if (isNaN(taruhan) || taruhan <= 0) {
      return m.reply('Masukkan jumlah taruhan yang valid!')
    }

    if (users.balance < taruhan) {
      return m.reply('Kamu tidak memiliki saldo yang cukup untuk bertaruh.')
    }

    const hasilRoda = Math.floor(Math.random() * 10) + 1 // Roda memiliki 10 pilihan
    const hadiah = [
      { hasil: 1, reward: taruhan * 10, text: 'Jackpot! Kamu menang besar!' },
      { hasil: 2, reward: taruhan * 5, text: 'Selamat! Kamu menang 5x taruhan!' },
      { hasil: 3, reward: taruhan * 2, text: 'Menang! Kamu mendapatkan 2x taruhan!' },
      { hasil: 4, reward: 0, text: 'Sayang sekali, tidak ada hadiah.' },
      { hasil: 5, reward: 0, text: 'Hasilnya nol, coba lagi.' },
      { hasil: 6, reward: 0, text: 'Hasilnya nol, coba lagi.' },
      { hasil: 7, reward: 0, text: 'Hasilnya nol, coba lagi.' },
      { hasil: 8, reward: 0, text: 'Hasilnya nol, coba lagi.' },
      { hasil: 9, reward: 0, text: 'Sayang sekali, kamu kehilangan taruhan.' },
      { hasil: 10, reward: 0, text: 'Sayang sekali, kamu kehilangan taruhan.' }
    ]

    users.lastWheel = now

    const result = hadiah.find(h => h.hasil === hasilRoda)

    if (result.reward > 0) {
      users.balance += result.reward
      return m.reply(
        `───「 *RODA KEBERUNTUNGAN* 」───\n\n` +
        `Hasil putaran roda: *${hasilRoda}*\n` +
        `${result.text}\n` +
        `Hadiah: +${func.formatRupiah ? func.formatRupiah(result.reward) : result.reward}`
      )
    } else {
      users.balance -= taruhan
      return m.reply(
        `───「 *RODA KEBERUNTUNGAN* 」───\n\n` +
        `Hasil putaran roda: *${hasilRoda}*\n` +
        `${result.text}\n` +
        `Kamu kehilangan taruhan sebesar ${func.formatRupiah ? func.formatRupiah(taruhan) : taruhan}.`
      )
    }
  }
}