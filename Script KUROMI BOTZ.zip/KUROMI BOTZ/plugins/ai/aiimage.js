const axios = require("axios");

async function generateImage(prompt) {
  try {
    const url = `https://1yjs1yldj7.execute-api.us-east-1.amazonaws.com/default/ai_image?prompt=${encodeURIComponent(prompt)}&aspect_ratio=1:1&link=writecream.com`;

    const headers = {
      "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36",
      "Referer": "https://www.writecream.com/ai-image-generator-free-no-sign-up/"
    };

    let { data } = await axios.get(url, { headers });
    if (data && data.image_link) return { success: true, imageUrl: data.image_link };
    return { success: false, message: "❌ Gagal mendapatkan gambar!" };
  } catch (error) {
    console.error("Error generating AI image:", error);
    return { success: false, message: "❌ Terjadi kesalahan saat membuat gambar!" };
  }
}

exports.run = {
  usage: ['aigen', 'aiimage'],
  hidden: [],
  use: 'Generate AI Image berdasarkan prompt',
  category: 'ai',
  async: async (m, { kuromi }) => {
    if (!m.text) return kuromi.sendMessage(m.chat, { text: `🚨 Masukkan prompt gambar!\n\nContoh: .aigen anime girl with blue hair` }, { quoted: m });

    kuromi.sendMessage(m.chat, { text: "🎨 Generating AI Image..." }, { quoted: m });

    let result = await generateImage(m.text);
    if (!result.success) return kuromi.sendMessage(m.chat, { text: result.message }, { quoted: m });

    await kuromi.sendMessage(m.chat, { react: { text: '🎨', key: m.key } });

    await kuromi.sendMessage(m.chat, { 
      image: { url: result.imageUrl }, 
      caption: `🖼️ *AI Image Generator*\n\n🎨 *Prompt:* ${m.text}` 
    }, { quoted: m });

    kuromi.sendMessage(m.chat, { text: "✅ Gambar berhasil dibuat!" }, { quoted: m });
  }
};