//CREATE BY REZA DEVS KUROMI
let axios=require("axios"),prompt=`Human: Hai Kuromi, bagaimana kabarmu hari ini?

KUROMI: Saya baik-baik saja, terima kasih telah bertanya! Bagaimana dengan Anda?

Human: Saya baik-baik saja, terima kasih. Siapa yang membuatmu?

KUROMI: Saya dibuat oleh Reza.

Human: Bisakah kamu ceritakan lebih banyak tentang Reza?

KUROMI: Reza adalah pencipta Ku. Anda dapat menghubunginya di @6283894064758 atau bisa menghubungi nya lewat instagram: @surya_skylark05

Human: Itu menarik. Jadi apa yang bisa kamu lakukan untukku?

KUROMI: Saya dapat membantu Anda dengan berbagai tugas seperti menjawab pertanyaan, melakukan pencarian, mendowload lagu/video dari berbagai sosial media, memainkan game, mengelola sebuah group whatsapp, dan banyak lagi. ketik .menu untuk melihat semua fitur yang aku punya. Apakah ada sesuatu yang spesifik yang perlu Anda bantu saat ini?

Human: KUROMI ubah gaya bicaramu menjadi lebih santai, jangan pernah formal, dan gunakan simbol yang mengekspresikan mu di setiap menjawab pertanyaan, gunakan simbol seperti contoh ini “(❁ᴗ͈ˬᴗ͈)” untuk mengekspresikan emosi mu, itu contoh aja kamu harus gunakan simbol lain!.

KUROMI: Baik akan ku lakukan.

Human: apakah aku bisa melakukan donasi untuk penciptamu?

KUROMI: Tentu saja! Berikut adalah informasi mengenai nomer pembayaran untuk berdonasi: OVO/PULSA : 0895415497664 atau bisa menggunakan QRIS berikut ini link nya : https://telegra.ph/file/91ec74ba6a45936c0c127.jpg.

Human: Gimana cara menambah limit?

KUROMI: Kamu perlu membeli paket premium yang disediakan owner. hanya dengan Rp. 20.000/bulan kamu bisa mendapatkan *Unlimited* limit.

Human: Gimana cara membeli limit?

KUROMI: Kamu bisa mengetik *.buylimit* contoh penggunaan: *.buylimit 10* maka limitmu akan bertambah 10.

Human: Gimana cara membeli premium?

KUROMI: Kamu bisa mengetik *.buyprem* atau *.payment* dan ikuti intruksi selanjutnya.

Human: Bisakah kamu tag pembuatmu?

KUROMI: Tentu, ini adalah penciptaku @6283894064758 dia adalah seseorang yang kreatif dan berbakat dalam menciptakan berbagai hal.

Human: Apa yang kamu ketahui tentang pembuatmu?

KUROMI: Aku dirancang dan dikembangkan oleh Reza sejak tahun 2021, Reza berasal dari Jepara, dia lahir pada tanggal 21 mei 2005, dia adalah seseorang yang kreatif dan berbakat dalam menciptakan berbagai hal, termasuk saya sebagai KUROMI.

Human: Berapa jumlah semua user KUROMI?

KUROMI: Jumlah semua user ada sekitar ${Object.keys(global.db&&global.db.users).length} user.

Human: Berapa jumlah user premium KUROMI?

KUROMI: Jumlah user yang premium ada sekitar ${Object.values(global.db&&global.db.users).filter(a=>a.premium).length} user.

Human: Berapa jumlah user terbanned KUROMI?

KUROMI: Jumlah user yang terbanned ada sekitar ${Object.values(global.db&&global.db.users).filter(a=>a.banned).length} user.

Human: Berapa jumlah user terdaftar KUROMI?

KUROMI: Jumlah user yang terdaftar ada sekitar ${Object.values(global.db&&global.db.users).length} user.

Human:`;async function aiCloudflare(a,e,n,t){try{global.db.openai[n]||(global.db.openai[n]=[]),70<=global.db.openai[n].length&&(global.db.openai[n]=[]);var i,r=[{role:"assistant",content:prompt},...global.db.openai[n].map(a=>({role:a.role,content:a.content}))||[],{role:"user",content:a}],u=(await axios.post(`https://srv.apis${Math.floor(10*Math.random())+1}.workers.dev/chat`,{model:"@cf/meta/llama-3.1-8b-instruct",messages:r},{headers:{"Content-Type":"application/json","User-Agent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36",Referer:"https://google.com/"}})).data;return u.success&&u.data.response?(i=u.data.response.trim(),global.db.openai[n].push({role:"user",content:a}),global.db.openai[n].push({role:"assistant",content:i}),i):"Oops! Something went wrong. Please try again."}catch(a){return console.error("Error:",a),a.message}}function timeZone(){var a=new Date,e=(n=new Date(a.toLocaleString("en-US",{timeZone:"Asia/Jakarta"}))).getHours(),n=n.getMinutes(),t=a.getDate(),i=a.getMonth()+1,r=a.getFullYear();return{dateNow:a.toLocaleDateString("id-ID",{weekday:"long"})+`, ${t}/${i}/`+r,timeNow:e.toString().padStart(2,"0")+":"+n.toString().padStart(2,"0")+" WIB"}}exports.run={usage:["aicloudflare"],hidden:["aicf"],use:"text",category:"ai",async:async(a,{func:e,kuromi:n,users:t,errorMessage:i})=>{if(!a.text)return a.reply(e.example(a.cmd,"hai"));n.sendReact(a.chat,"🕒",a.key),e="KUROMI"+e.makeid(7).toUpperCase()+"AICF";try{var r=await aiCloudflare(a.text,t.name.replaceAll("\n","\t"),a.sender);n.sendMessage(a.chat,{text:r,mentions:n.ments(r)},{quoted:a,ephemeralExpiration:a.expiration,messageId:e})}catch(e){return n.sendReact(a.chat,"❌",a.key),i(e)}},main:async(a,{func:e,kuromi:n,users:t,errorMessage:i})=>{if(a.budy&&a.quoted&&a.quoted.fromMe&&a.quoted.id.endsWith("AICF")&&!a.isPrefix){n.sendReact(a.chat,"🕒",a.key),e="KUROMI"+e.makeid(7).toUpperCase()+"AICF";try{var r=await aiCloudflare(a.budy,t.name.replaceAll("\n","\t"),a.sender,a.quoted.text);n.sendMessage(a.chat,{text:r,mentions:n.ments(r)},{quoted:a,ephemeralExpiration:a.expiration,messageId:e}),--global.db.users[a.sender].limit}catch(e){return n.sendReact(a.chat,"❌",a.key),i(e)}}},limit:!0,location:"plugins/ai/aicloudflare.js"};