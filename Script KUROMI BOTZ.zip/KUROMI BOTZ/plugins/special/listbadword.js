//CREATE BY REZA DEVS KUROMI
let fetch=require("node-fetch");exports.run={usage:["listbadword"],category:"special",async:async(e,{kuromi:a,setting:t})=>{if(0==t.toxic.length)return e.reply("Empty data.");var i=`乂  *LIST BAD WORD*

Total : ${t.toxic.length}
`;i+=t.toxic.map((e,a)=>a+1+". "+e).join("\n"),await(t.fakereply?a.sendMessageModify(e.chat,i,e,{title:global.header,body:global.footer,thumbnail:await(await fetch(t.cover)).buffer(),largeThumb:!0,expiration:e.expiration}):a.reply(e.chat,i,e,{expiration:e.expiration}))}};