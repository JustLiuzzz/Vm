/* CODE LAIN CHEK
https://whatsapp.com/channel/0029VbARSvBCMY0PDV53rt0m
JANGAN LUPA FOLLOW
*/

let fetch = require("node-fetch");
exports.run = {
    usage: ["infobot", "script"],
    hidden: ["botinfo", "sc"],
    category: "special",
    async: async (a, {
        func: e,
        kuromi: s,
        setting: t
    }) => {
        var i = require("fs"),
            o = require("node-fetch"),
            r = i.existsSync("./node_modules/baileys") ? "baileys" : i.existsSync("./node_modules/@adiwajshing/baileys") ? "@adiwajshing/baileys" : "@whiskeysockets/baileys",
            {} = require(r);
        switch (a.command) {
            case "script":
            case "sc":
               let text = `*SELL SCRIPT KUROMI BOT*

- Harga ? 50k
- Features: 1000+
- Type: plugins (CJS)
- Demo Bot ? Chat wa.me/6289502423402?text=.menu

*Key Features:*
- Support QR/Pairing
- Support button
- Size dibawah ringan
- Menggunakan Scraper & website res api
- Login with username & password to get access

*Preview Features:*
- Downloader (tiktok, instagram, facebook, snackvideo, twitter, capcut, youtube dll)
- Tiktok Search
- AI & AI Image
- Imagehd
- Hdvideo
- 31 Mini Games & RPG Games
- Response Polling
- Button List
- Advanced Menu Options
- And more...

*Additional Features:*
- Temporary Bot (Jadibot)
- Menfess (Confession)
- Create Panel
- Auto Downloader
- Anonymous Chat
- And more...

*Benefit:*
- Free update Menggunakan Sistem Update Otomatis 
- Request Features
- Fixing Features
- Free Panel (1 month)

Jika anda berminat silahkan hubungi
wa.me/6283894064758`
a.reply(text)
                
                break;
            case "infobot":
            case "botinfo":
                n = `乂  *BOT INFORMATION*

*› Creator*: Reza
*› Creator Name*: Reza
*› Bot Name*: Kuromi Bot
*› Library*: @whiskeysockets/baileys^${require(r+"/package.json").version}
*› Versions*: Kuromi Bot v${require("../../package.json").version}
*› Memory Used*: ${e.fileSize(process.memoryUsage().rss)} / ${null!=process.env.SERVER_MEMORY&&0!=process.env.SERVER_MEMORY?process.env.SERVER_MEMORY+" MB":"∞"}
*› Hostname*: ${process.env.HOSTNAME??"-"}
*› Platform*: ${process.platform+" "+process.arch}
*› Mode*: ${t.self?"Self":"Public"}
*› Total User*: ${Object.keys(global.db.users).length} Users
*› Total Group:* ${Object.keys(global.db.groups).length} Groups
*› Deskripsi*:

Kuromi adalah Bot WhatsApp dengan program kecerdasan buatan AI (artificial intelligence).
Sistem bot ini mampu berperan aktif sebagai asisten virtual yang membalas setiap pesan WhatsApp secara otomatis dalam hitungan detik.

Bot ini Dirancang dan Dikembangkan Oleh Reza.`;
                await (t.fakereply ? s.sendMessageModify(a.chat, n, a, {
                    title: global.header,
                    body: global.footer,
                    thumbnail: await (await o(t.cover)).buffer(),
                    largeThumb: !0,
                    expiration: a.expiration
                }) : a.reply(n))
        }
    },
    location: "plugins/special/infobot.js"
};