//CREATE BY REZA DEVS KUROMI
let fetch=require("node-fetch");exports.run={usage:["hitdaily"],category:"special",async:async(i,{func:o,kuromi:t,setting:a})=>{var e=Object.entries(global.db.statistic).map(t=>t[1].hittoday).reduce((t,a)=>t+a);if(0==e)return i.reply("No command used.");e=`乂  *H I T - D A I L Y*

*“Total command hit statistics for today ${e} Hits.”*
`+Object.entries(global.db.statistic).sort((t,a)=>a[1].hittoday-t[1].hittoday).slice(0,10).map(([t,a],e)=>`
${e+1}. *Command* : ${i.prefix+t}
    *Hit* : ${o.formatNumber(a.hittoday)}
    *Last Hit* : `+(Date.now()-a.lastused).timers()).join("\n"),await(a.fakereply?t.sendMessageModify(i.chat,e,i,{title:global.header,body:global.footer,thumbnail:await(await fetch(a.cover)).buffer(),largeThumb:!0,expiration:i.expiration}):t.reply(i.chat,e,i,{expiration:i.expiration}))}};