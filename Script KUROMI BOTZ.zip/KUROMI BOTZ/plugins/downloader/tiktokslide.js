//CREATE BY REZA DEVS KUROMI
let axios=require("axios"),cheerio=require("cheerio");async function ttSlide(d){try{let e=(await axios.post("https://ttsave.app/download",{query:d,language_id:"2"},{headers:{Accept:"application/json, text/plain, */*","Content-Type":"application/json"}})).data,n=cheerio.load(e),t=n("#unique-id").val(),a=n("h2.font-extrabold.text-xl.text-center").text(),r=n('a[target="_blank"]').attr("href"),i=n("img.h-24.w-34.rounded-full").attr("src"),s=n("p.text-gray-600.px-2.text-center.break-all.w-3/4.oneliner").text(),o={views:n("svg.h-5.w-5.text-gray-500 + span").text(),likes:n("svg.h-5.w-5.text-red-500 + span").text(),comments:n("svg.h-5.w-5.text-green-500 + span").text(),shares:n("svg.h-5.w-5.text-yellow-500 + span").text(),downloads:n("svg.h-5.w-5.text-blue-500 + span").text()},l=[];return n('a[onclick="bdl(this, event)"]').each((e,t)=>{var a=n(t).attr("href"),r=n(t).attr("type"),t=n(t).text().trim();l.push({link:a,type:r,title:t})}),{uniqueId:t,username:a,thumbnail:r,profile:i,description:s,stats:o,download:l}}catch(d){throw console.error(d),d}}exports.run={usage:["tiktokslide"],hidden:["ttslide"],use:"link tiktok",category:"downloader",async:async(r,{func:n,kuromi:i})=>{if(!r.text)return r.reply(n.example(r.cmd,"https://vt.tiktok.com/ZSYYYW4tk/"));if(!r.args[0].includes("tiktok.com"))return r.reply(mess.error.url);i.sendReact(r.chat,"🕒",r.key);try{var e=await ttSlide(r.args[0]);if(0==e.download.length)return r.reply("Empty data.");let t=e.download.find(e=>"audio"==e.type),a=e.download.filter(e=>"slide"==e.type);var s=e.stats,o=`乂  *T I K T O K - S L I D E*
`,o=(o+=`
- Username : `+e.username)+`
UniqueId : `+e.uniqueId+`
- Views : `+(s.views??"-")+`
- Likes : `+(s.likes??"-")+`
- Comments : `+(s.comments??"-")+`
- Shares : `+(s.shares??"-")+`
- Downloads : `+(s.downloads??"-")+`
- Total Images : `+a.length+`

_Please wait image is being sent..._`;await i.sendMessage(r.chat,{text:o},{quoted:r,ephemeralExpiration:r.expiration}).then(async()=>{if(t&&await i.sendMessage(r.chat,{audio:{url:t.link},mimetype:"audio/mpeg",ptt:!1},{quoted:r,ephemeralExpiration:r.expiration}),0==a.length)return r.reply("Image not found.");for(var e of a)i.sendMessage(r.chat,{image:{url:e.link}},{ephemeralExpiration:r.expiration}),await n.delay(1e3)})}catch(e){return console.error(e),i.reply(r.chat,String(e),r)}},premium:!0};