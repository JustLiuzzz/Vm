const axios = require('axios');
const cheerio = require('cheerio');

async function scrapeApoki(query) {
  const baseURL = `https://bokepi.com/?s=${encodeURIComponent(query)}`;
  try {
    const { data } = await axios.get(baseURL);
    const $ = cheerio.load(data);
    const results = [];

    $('article.thumb-block').each((i, el) => {
      const title = $(el).find('header.entry-header span').text().trim();
      const url = $(el).find('a').attr('href');
      const thumbnail = $(el).find('.post-thumbnail').attr('data-thumbs');

      if (title && url && thumbnail) {
        results.push({ title, url, thumbnail });
      }
    });

    return results;
  } catch (error) {
    console.error('Scrape failed:', error.message);
    return [];
  }
}

exports.run = {
  usage: ['bokepisearch'],
  hidden: ['caribokep'],
  use: 'query',
  category: 'downloader',
  async: async (m, { kuromi }) => {
    if (!m.text) return m.reply('Masukkan kata kunci pencarian, contoh: bokepisearch colmek');

    const results = await scrapeApoki(m.text);
    if (!results.length) return m.reply('Tidak ada hasil ditemukan.');

    const listText = results.map((v, i) => `${i + 1}. *${v.title}*\n${v.url}`).join('\n\n');
    const first = results[0];

    await kuromi.sendMessage(m.chat, {
      image: { url: first.thumbnail },
      caption: `Hasil pencarian untuk: *${m.text}*\n\n${listText}`
    }, { quoted: m });
  },
  location: "plugins/downloader/bokepisearch.js"
};