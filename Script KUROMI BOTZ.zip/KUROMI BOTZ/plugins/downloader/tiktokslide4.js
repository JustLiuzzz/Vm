//CREATE BY REZA DEVS KUROMI
let axios=require("axios"),cheerio=require("cheerio");async function ttSlide(d){try{let e=(await axios.post("https://ttsave.app/download",{query:d,language_id:"2"},{headers:{Accept:"application/json, text/plain, */*","Content-Type":"application/json"}})).data,i=cheerio.load(e),t=i("#unique-id").val(),a=i("h2.font-extrabold.text-xl.text-center").text(),r=i('a[target="_blank"]').attr("href"),n=i("img.h-24.w-34.rounded-full").attr("src"),s=i("p.text-gray-600.px-2.text-center.break-all.w-3/4.oneliner").text(),o={views:i("svg.h-5.w-5.text-gray-500 + span").text(),likes:i("svg.h-5.w-5.text-red-500 + span").text(),comments:i("svg.h-5.w-5.text-green-500 + span").text(),shares:i("svg.h-5.w-5.text-yellow-500 + span").text(),downloads:i("svg.h-5.w-5.text-blue-500 + span").text()},l=[];return i('a[onclick="bdl(this, event)"]').each((e,t)=>{var a=i(t).attr("href"),r=i(t).attr("type"),t=i(t).text().trim();l.push({link:a,type:r,title:t})}),{uniqueId:t,username:a,thumbnail:r,profile:n,description:s,stats:o,download:l}}catch(d){throw console.error(d),d}}exports.run={usage:["tiktokslide4"],hidden:["ttslide4"],use:"link tiktok",category:"downloader",async:async(r,{func:i,kuromi:n})=>{if(!r.text)return r.reply(i.example(r.cmd,"https://vt.tiktok.com/ZSYYYW4tk/"));if(!r.args[0].includes("tiktok.com"))return r.reply(mess.error.url);n.sendReact(r.chat,"🕒",r.key);try{var e=await ttSlide(r.args[0]);if(0==e.download.length)return r.reply("Empty data.");let t=e.download.find(e=>"audio"==e.type),a=e.download.filter(e=>"slide"==e.type);var s=e.stats,o=`乂  *T I K T O K - S L I D E*
`,o=(o+=`
- Username : `+e.username)+`
UniqueId : `+e.uniqueId+`
- Views : `+(s.views??"-")+`
- Likes : `+(s.likes??"-")+`
- Comments : `+(s.comments??"-")+`
- Shares : `+(s.shares??"-")+`
- Downloads : `+(s.downloads??"-")+`
- Total Images : `+a.length+`

_Please wait image is being sent..._`;await n.sendMessage(r.chat,{text:o},{quoted:r,ephemeralExpiration:r.expiration}).then(async()=>{if(t&&await n.sendMessage(r.chat,{audio:{url:t.link},mimetype:"audio/mpeg",ptt:!1},{quoted:r,ephemeralExpiration:r.expiration}),0==a.length)return r.reply("Image not found.");for(var e of a)n.sendMessage(r.chat,{image:{url:e.link}},{ephemeralExpiration:r.expiration}),await i.delay(1e3)})}catch(e){return console.error(e),n.reply(r.chat,String(e),r)}},limit:5};