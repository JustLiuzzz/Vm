//CREATE BY REZA DEVS KUROMI
let cheerio=require("cheerio"),axios=require("axios"),headers={authority:"ttsave.app",accept:"application/json, text/plain, */*",origin:"https://ttsave.app",referer:"https://ttsave.app/en","user-agent":"Postify/1.0.0"},ttsave={submit:async function(e,t){return t={...headers,referer:t},e={query:e,language_id:"1"},axios.post("https://ttsave.app/download",e,{headers:t})},parse:function(i){let e=i("#unique-id").val(),t=i("h2.font-extrabold").text(),a=i("img.rounded-full").attr("src"),s=i("a.font-extrabold.text-blue-400").text(),r=i("p.text-gray-600").text(),n={nowm:i("a.w-full.text-white.font-bold").first().attr("href"),wm:i("a.w-full.text-white.font-bold").eq(1).attr("href"),audio:i("a[type='audio']").attr("href"),profilePic:i("a[type='profile']").attr("href"),cover:i("a[type='cover']").attr("href")},o={plays:"",likes:"",comments:"",shares:""};i(".flex.flex-row.items-center.justify-center").each((e,t)=>{var a=(t=i(t)).find("svg path").attr("d"),t=t.find("span.text-gray-500").text().trim();a&&a.startsWith("M10 18a8 8 0 100-16")?o.plays=t:a&&a.startsWith("M3.172 5.172a4 4 0 015.656")?o.likes=t||"0":a&&a.startsWith("M18 10c0 3.866-3.582")?o.comments=t:a&&a.startsWith("M17.593 3.322c1.1.128")&&(o.shares=t)});var l=i(".flex.flex-row.items-center.justify-center.gap-1.mt-5").find("span.text-gray-500").text().trim(),d=i("a[type='slide']").map((e,t)=>({number:e+1,url:i(t).attr("href")})).get();return{uniqueId:e,nickname:t,profilePic:a,username:s,description:r,dlink:n,stats:o,songTitle:l,slides:d}},video:async function(e){try{var t=await this.submit(e,"https://ttsave.app/en"),a=cheerio.load(t.data),i=this.parse(a);return i.slides&&0<i.slides.length?{type:"slide",...i}:{type:"video",...i,videoInfo:{nowm:i.dlink.nowm,wm:i.dlink.wm}}}catch(e){throw console.error(e),e}}};exports.run={usage:["tiktok6"],hidden:["tiktokslide3","ttslide3"],use:"link tiktok",category:"downloader",async:async(i,{func:s,kuromi:r})=>{if(!i.text)return i.reply(s.example(i.cmd,"https://vt.tiktok.com/ZS6tejpuf/"));if(!/^(?:https?:\/\/)?(?:www\.|vt\.|vm\.|t\.)?(?:tiktok\.com\/)(?:\S+)?$/.test(i.args[0]))return i.reply(global.mess.error.url);r.sendReact(i.chat,"🕒",i.key);try{let e=await ttsave.video(i.args[0]),t=e.stats,a=`
- Title : `+e.description;if(a=(a=(a=(a=(a=(a=(a=(a+=`
- Username : `+e.username)+`
- Nickname : `+e.nickname)+`
- Plays : `+t.plays)+`
- Likes : `+t.likes)+`
- Comments : `+t.comments)+`
- Shares : `+t.shares)+`
- Song Title : `+e.songTitle)+`
- Uniqueid : `+e.uniqueId,"slide"===e.type){a=(a=`乂  *TIKTOK - SLIDE*
`+a)+`
- Total Images : `+e.slides.length+`

_Please wait image is being sent..._`;for(var[n,o]of e.slides.entries()){var l=0==n?i:null;await r.sendMedia(i.chat,o.url,l,{caption:0==n?a:"",expiration:i.expiration}),await s.delay(1e3)}}else"video"===e.type&&(a=`乂  *TIKTOK - DOWNLOADER*
`+a,a+=`

_Please wait video is being sent..._`,e.dlink.nowm?r.sendMedia(i.chat,e.dlink.nowm,i,{caption:a,expiration:i.expiration}):r.sendMedia(i.chat,e.dlink.wm,i,{caption:capt,expiration:i.expiration}));r.sendMessage(i.chat,{audio:{url:e.dlink.audio},mimetype:"audio/mpeg",ptt:!1},{quoted:i,ephemeralExpiration:i.expiration})}catch(e){console.log(e),r.reply(i.chat,e.message,i,{expiration:i.expiration})}},location:"plugins/downloader/tiktokslide3.js"};