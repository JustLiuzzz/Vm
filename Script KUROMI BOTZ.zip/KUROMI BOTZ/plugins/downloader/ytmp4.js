const fetch = require('node-fetch')

exports.run = {
  usage: ['ytmp4'], // command utama
  hidden: ['ytvideo', 'ytv'], // command simpel
  use: 'URL YouTube [kualitas]', // deskripsi
  category: 'downloader', // kategori
  premium: true, // fitur premium karena akses API dan potensi resource tinggi
  async: async (m, { func, kuromi, isPrem }) => {
    if (!m.text) return m.reply('✉ URL YouTube diperlukan.\nContoh: .ytmp4 https://youtu.be/xxxxx 720')

    const [url, res] = m.text.split(' ')
    const resolution = res && /^\d{3,4}$/.test(res) ? res : '360'

    // Kirim reaksi jam pasir untuk menunjukkan proses sedang berjalan
    await kuromi.sendMessage(m.chat, { text: '⏳ Tunggu sebentar, sedang memproses video...' }, { quoted: m })

    try {
      const response = await fetch(`https://cloudkutube.eu/api/ytv?url=${encodeURIComponent(url)}&resolution=${resolution}`)
      const data = await response.json()

      if (data.status !== 'success') return m.reply('Gagal mendapatkan video.')

      const {
        title, uploader, uploadDate,
        views, likes, resolution: usedRes,
        fileSize, url: videoUrl,
        thumbnail
      } = data.result

      const caption = `┌───〔 YOUTUBE VIDEO 〕
│ 
│ Judul     : ${title}
│ Channel   : ${uploader}
│ Upload    : ${uploadDate}
│ Views     : ${views}
│ Likes     : ${likes}
│ 
│ Kualitas  : ${usedRes}
│ Ukuran    : ${fileSize}
└───────────────`

      await kuromi.sendMessage(m.chat, {
        video: { url: videoUrl },
        caption,
        contextInfo: {
          externalAdReply: {
            title: title,
            body: `Quality: ${usedRes}`,
            thumbnailUrl: thumbnail,
            sourceUrl: 'https://cloudkutube.eu',
            mediaType: 1,
            renderLargerThumbnail: true,
            showAdAttribution: true
          },
          forwardingScore: 999,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterJid: "120363370918801903@newsletter",
            serverMessageId: 1102,
            newsletterName: "Cloudkuimages Information"
          }
        }
      }, { quoted: m })

    } catch (e) {
      console.error(e)
      return m.reply(`Maaf, gagal mengunduh video.\n${e.message}`)
    }
  },
  location: "plugins/downloader/ytmp4.js" // lokasi file
}