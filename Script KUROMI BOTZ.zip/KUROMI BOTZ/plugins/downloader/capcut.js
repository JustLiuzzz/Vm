//CREATE BY REZA DEVS KUROMI
let axios=require("axios");async function capcut(t){t={url:t};try{var a=(await axios.post("https://api.teknogram.id/v1/capcut",t,{headers:{"Content-Type":"application/json; charset=UTF-8"}})).data;return{status:a.status,title:a.title,size:a.size,url:a.url.replace("open.","")}}catch(t){return console.error("Error:",t),null}}exports.run={usage:["capcut"],hidden:["cc"],use:"url capcut",category:"downloader",async:async(t,{kuromi:a})=>{if(!t.text)return t.reply(`Masukkan URL!

Contoh: *${t.cmd} https://www.capcut.com/t/Zs8YEmRmj/*`);if(!t.args[0].includes("www.capcut.com"))return t.reply(global.mess.error.url);a.sendReact(t.chat,"🕒",t.key);var e=await capcut(t.args[0]),r=`乂  *CAPCUT DOWNLOADER*

◦ Title: ${e.title}
◦ Size: `+e.size;a.sendMedia(t.chat,e.url,t,{caption:r,expiration:t.expiration})},premium:!0,limit:5};