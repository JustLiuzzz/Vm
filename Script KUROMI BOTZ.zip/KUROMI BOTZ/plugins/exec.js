const fs = require('fs'),
    chalk = require('chalk'),
    util = require('util'),
    path = require('path'),
    crypto = require('crypto'),
    moment = require('moment-timezone'),
    phonenumber = require('awesome-phonenumber'),
    baileys = require('@whiskeysockets/baileys'),
    toMs = require('ms'),
    yts = require('yt-search'),
    ytdl = require('ytdl-core'),
    axios = require('axios'),
    cheerio = require('cheerio'),
    request = require('request'),
    ms = require('parse-ms'),
    fetch = require('node-fetch');
const {
    exec
} = require('child_process');

exports.run = {
    main: async (m, {
        extra,
        func,
        kuromi,
        plugins,
        update,
        store,
        users,
        groups,
        setting,
        week,
        time,
        calender,
        packname,
        author,
        isBanned,
        isPrem,
        quoted,
        mime,
        fkon,
        errorMessage,
        YT,
        commands
    }) => {
        function get(jid) {
            if (jid.endsWith('@g.us')) {
                return global.db.groups[jid]
            } else {
                jid = jid.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                return global.db.users[jid]
            }
        };

        function checkVIPMember(jid) {
            if (/^\d.*(@g\.us)$/.test(m.chat)) {
                let groups = global.db.groups[m.chat];
                if (groups.sewa && groups.sewa.status && groups.sewa.vip) {
                    let metadata = global.db.metadata[m.chat] || {};
                    let members = metadata?.participants?.map(x => x.id) || [];
                    if (members.includes(jid)) return true;
                }
            }
            return false;
        }

        function isJid(text = '') {
            const cleanedText = text.replace(/[^0-9]/g, '');
            return cleanedText.length > 0 && !isNaN(cleanedText) ?
                cleanedText + '@s.whatsapp.net' :
                false;
        }

        const froms = m.quoted ? m.quoted.sender : m.text ? isJid(m.text) : false;

        let target;
        if (froms) {
            target = global.db.users[froms];
        }

        if (m.budy && m.isDevs) {
            if ((m.isPc || (m.isGc && !groups.mute)) && setting.evaluate && !m.budy.startsWith(m.prefix)) {
                try {
                    let evaled = await eval(m.budy)
                    if (typeof evaled !== 'string') evaled = util.inspect(evaled)
                    kuromi.sendMessage(m.chat, {
                        text: util.format(evaled)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                } catch (e) {
                    kuromi.sendMessage(m.chat, {
                        text: util.format(e)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                }
            }

            // EVAL & EXEC CODE
            if (/^(x|xx)$/.test(m.command)) {
                let text;
                if (m.command === 'x') text = m.text ? m.text : false;
                else if (m.command === 'xx') text = m.quoted && m.quoted.text ? m.quoted.text : m.text ? m.text : false
                if (!text) return false;
                let evalCmd;
                try {
                    evalCmd = /await/i.test(text) ? eval("(async () => { " + text + " })()") : eval(text)
                    let evaled = await evalCmd;
                    if (typeof evaled !== 'string') evaled = util.inspect(evaled)
                    kuromi.sendMessage(m.chat, {
                        text: util.format(evaled)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                } catch (error) {
                    kuromi.sendMessage(m.chat, {
                        text: util.format(error)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                }
            } else if (m.command === '=>') {
                if (!m.text) return false;
                try {
                    let evaled = await eval(`(async () => { return ${m.text} })()`)
                    kuromi.sendMessage(m.chat, {
                        text: util.format(evaled)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                } catch (e) {
                    kuromi.sendMessage(m.chat, {
                        text: util.format(e)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                }
            } else if (m.command === '$') {
                if (!m.text) return false;
                kuromi.sendReact(m.chat, '🕒', m.key)
                exec(m.text, (err, stdout) => {
                    if (err) return kuromi.sendMessage(m.chat, {
                        text: err.toString()
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                    if (stdout) return kuromi.sendMessage(m.chat, {
                        text: util.format(stdout)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                })
            }
        }
    },
    location: 'plugins/exec.js',
    devs: true
}