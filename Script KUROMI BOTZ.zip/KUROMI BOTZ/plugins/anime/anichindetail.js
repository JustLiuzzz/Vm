exports.run = {
  usage: ['anichindetail'],
  hidden: ['anichin'],
  use: 'url',
  category: 'anime',
  premium: true,
  async: async (m, { kuromi }) => {
    try {
      if (!m.text) return m.reply('Masukkan URL Anichin.\nContoh:\n.anichindetail https://anichin.forum/renegade-immortal-episode-69-subtitle-indonesia/')

      let res = await kuromi.fetch(`https://api.siputzx.my.id/api/anime/anichin-detail?url=${encodeURIComponent(m.text)}`)
      let json = await res.json()

      if (!json.status) return m.reply('Gagal mengambil data.')

      let caption = `*${json.result.title}*\n\n`
      caption += `*Sinopsis:* ${json.result.sinopsis}\n`
      caption += `*Episode:* ${json.result.episode}\n`
      caption += `*Rilis:* ${json.result.rilis}\n`
      caption += `*Download:*\n`

      for (let [resolusi, links] of Object.entries(json.result.download)) {
        caption += `\n*${resolusi}*\n`
        for (let link of links) {
          caption += `- ${link.title}: ${link.link}\n`
        }
      }

      await kuromi.sendFile(m.chat, json.result.thumbnail, 'thumbnail.jpg', caption, m)
    } catch (e) {
      console.error(e)
      m.reply('Terjadi kesalahan saat mengambil data.')
    }
  },
  location: "plugins/anime/anichindetail.js"
}