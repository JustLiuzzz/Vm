exports.run = {
  usage: ['anichinsearch'],
  use: 'cari donghua berdasarkan judul',
  category: 'anime',
  async: async (m, { kuromi, func }) => {
    const query = m.text
    if (!query) return m.reply(`Masukkan judul donghua!\n\nContoh:\n${m.prefix + m.command} naga`)
    
    m.reply('TUNGGU SEBENTAR KAK 5 DETIK AJA')
    
    let res = await fetch(`https://api.siputzx.my.id/api/anime/anichin-search?query=${encodeURIComponent(query)}`)
    let json
    
    try {
      json = await res.json();
    } catch (error) {
      return m.reply('Terjadi kesalahan dalam memproses data dari API.')
    }

    if (!json || !json.status || !json.data || !Array.isArray(json.data) || json.data.length === 0) {
      return m.reply('Data tidak ditemukan atau terjadi kesalahan saat memproses data.')
    }
    const list = json.data.slice(0, 5);
    for (let i = 0; i < list.length; i++) {
      const item = list[i]
      if (!m.chat) return m.reply("Terjadi masalah dengan chat, tidak dapat mengirim pesan.")
      await func.delay(5000)
      
      await kuromi.sendMessage(
        m.chat,
        {
          image: { url: item.image },
          caption: `*Foto ke-${i + 1} dari ${list.length}*\n\n*Title:* ${item.title}\n*Type:* ${item.type}\n*Status:* ${item.status}\n*Link:* ${item.link}`
        },
        { quoted: m }
      ).catch(error => m.reply(error.message))
    }
  },
  location: "plugins/anime/anichinsearch.js"
}