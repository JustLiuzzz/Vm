//CREATE BY REZA DEVS KUROMI
exports.run={usage:["zodiac"],hidden:["zodiak"],use:"year month date",category:"user",async:async(e,{func:a,kuromi:t,users:n})=>{if(!e.text)return e.reply(a.example(e.cmd,"2005 5 21"));let r=[["Capricorn",new Date(1970,0,1)],["Aquarius",new Date(1970,0,20)],["Pisces",new Date(1970,1,19)],["Aries",new Date(1970,2,21)],["Taurus",new Date(1970,3,21)],["Gemini",new Date(1970,4,21)],["Cancer",new Date(1970,5,22)],["Leo",new Date(1970,6,23)],["Virgo",new Date(1970,7,23)],["Libra",new Date(1970,8,23)],["Scorpio",new Date(1970,9,23)],["Sagittarius",new Date(1970,10,22)],["Capricorn",new Date(1970,11,22)]].reverse();if("Invalid Date"==(a=new Date(e.text)))return e.reply(a.toString());var[i,l,D]=[(u=new Date).getFullYear(),u.getMonth()+1,u.getDate()],o=[a.getFullYear(),a.getMonth()+1,a.getDate()],w=(e=>{let a=new Date(1970,e-1,o[2]);return r.find(([,e])=>a>=e)[0]})(o[1]),u=new Date(u-a).getFullYear()-new Date(1970,0,1).getFullYear(),a=[i+(o[1]<l),...o.slice(1)],i=l===o[1]&&D===o[2]?`Happy ${u}th Birthday 🥳🎉`:u,u=(l=a[2]+1+`/${a[1]}/`+a[0],D=new Date,l=l.split(/\D/),l=((u=new Date(l[2],--l[1],l[0]))&&u.getMonth()==l[1]||u.getMonth()==++l[1]?u:new Date(NaN))-D,Math.floor(l/2592e6)+` bulan ${Math.floor(l%2592e6/864e5)} hari lagi`),D=`乂  *Z O D I A C*
`,D=(D+=`
◦  *Nama :* `+(n.name||"@"+e.sender.split("@")[0]))+`
◦  *Tanggal lahir :* `+o.join("-")+`
◦  *Ultah mendatang :* `+a.join("-");t.reply(e.chat,(D+=`
◦  *Ultah :* `+u)+`
◦  *Umur :* `+i+`
◦  *Zodiak :* `+w,e)},limit:!0};