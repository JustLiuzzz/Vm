//CREATE BY REZA DEVS KUROMI
exports.run={usage:["listultah"],hidden:["ultahlist"],category:"user",async:async(l,{})=>{let t=Object.values(global.db.users).filter(l=>l.ultah).filter(l=>void 0!==l.ultah?.date),a="*B I R T H D A Y - L I S T*\n";t.forEach((l,t)=>{a+=`
${t+1}. @${l.jid.replace(/@.+/,"")} (${l.ultah.date})`}),l.reply(a)},location:"plugins/user/listultah.js"};