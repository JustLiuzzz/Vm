//CREATE BY REZA DEVS KUROMI
exports.run={usage:["jodohin"],use:"@tag",category:"user",async:async(a,{func:e})=>{if(!a.text)return a.reply(e.example(a.cmd,"@0"));if(!a.text.match("@"))return a.reply(e.example(a.cmd,"@0"));let t=a.text.replace(/[^0-9]/g,"")+"@s.whatsapp.net",p=(e=Object.values(global.db.metadata),[]);e.map(({participants:a})=>a.filter(a=>a.id!==t).map(a=>a.id)).map(a=>p.push(...a)),e=p[Math.floor(Math.random()*p.length)],a.reply(`Ciee yang Jadian👫 Jangan lupa pajak jadiannya

@${t.split("@")[0]} ❤️ @`+e.split("@")[0])},group:!0,limit:!0};