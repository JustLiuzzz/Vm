//CREATE BY REZA DEVS KUROMI
exports.run={usage:["cekpacar"],use:"mention or reply",category:"user",async:async(a,{func:n,froms:e})=>{var s,d;return a.quoted||a.text?(d="Orang yang kamu tag",null==global.db.users[e]||void 0===global.db.users[global.db.users[e].pasangan.id]&&""!=global.db.users[e].pasangan.id?a.reply("User data not found."):void(""==global.db.users[e].pasangan.id?a.reply(d+` tidak memiliki pasangan dan tidak sedang menembak siapapun

*Kirim ${a.prefix}tembak @tag untuk menembak seseorang*`):global.db.users[global.db.users[e].pasangan.id].pasangan.id!=e?a.reply(d+` sedang digantung oleh @${global.db.users[e].pasangan.id.split("@")[0]} karena tidak sedang di terima atau di tolak

*Kirim ${a.prefix}ikhlaskan untuk menghapus nama dia dari hatimu*`):(s=n.toTime(Date.now()-global.db.users[e].pasangan.time),a.reply(d+` sedang menjalani hubungan dengan @${global.db.users[e].pasangan.id.split("@")[0]} 🥳🥳
Selama `+s)))):null==global.db.users[a.sender]||void 0===global.db.users[global.db.users[a.sender].pasangan.id]&&""!=global.db.users[a.sender].pasangan.id?a.reply("User data not found."):void(""==global.db.users[a.sender].pasangan.id?a.reply(`Kamu tidak memiliki pasangan dan tidak sedang menembak siapapun

*Kirim ${a.prefix}tembak @tag untuk menembak seseorang*`):global.db.users[global.db.users[a.sender].pasangan.id].pasangan.id!=a.sender?a.reply(`Kamu sedang digantung oleh @${global.db.users[a.sender].pasangan.id.split("@")[0]} karena tidak sedang di terima atau di tolak

*Kirim ${a.prefix}ikhlaskan untuk menghapus nama dia dari hatimu*`):(d=n.toTime(Date.now()-global.db.users[a.sender].pasangan.time),a.reply(`Kamu sedang menjalani hubungan dengan @${global.db.users[a.sender].pasangan.id.split("@")[0]} 🥳🥳
Selama `+d)))},group:!0};