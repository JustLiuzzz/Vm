//CREATE BY REZA DEVS KUROMI
exports.run={usage:["cupidmeter"],use:"nama1 nama2",category:"user",async:async(l,{func:o,kuromi:d})=>{if(!l.text||l.text.split(" ").length<2)return l.reply(o.example(l.cmd,"Reza Mecha"));var h=(o=l.text.split(" "))[0],o=o[1],a=a=>2<=a.length&&/^[a-zA-Z]+$/.test(a);if(!a(h)||!a(o))return l.reply("Nama harus berisi huruf dan minimal 2 karakter.");console.log(`Permintaan pengecekan kecocokan untuk: ${h} dan `+o);try{let a=((n,e)=>{let i=0;for(let a=0;a<n.length;a++)i=n.charCodeAt(a);for(let a=0;a<e.length;a++)i=e.charCodeAt(a);return i=i%100+1})(h,o),n=n=>{let a=["Kreatif","Penuh semangat","Setia","Empatis","Petualang","Murah hati","Sabar","Optimis","Berani","Handal"],e=0;for(let a=0;a<n.length;a++)e=n.charCodeAt(a);return a[e%a.length]},e=n(h),i=n(o),t=90<a?"💞 Pasangan yang Sempurna! Hubungan kalian tak terpisahkan dan penuh dengan cinta serta pengertian. Hargai hubungan ini!":70<a?"💕 Pasangan Hebat! Banyak kesamaan yang kuat dan mudah mengatasi perbedaan. Hubungan kalian memiliki pondasi yang kuat untuk tumbuh lebih dalam dan menyenangkan.":50<a?"💘 Pasangan Baik! Ada beberapa perbedaan, namun dengan usaha dan komunikasi, hubungan ini bisa berkembang dengan indah.":30<a?"💓 Pasangan Rata-rata! Kalian memiliki beberapa kesamaan, namun perlu bekerja untuk saling memahami dan menerima perbedaan satu sama lain.":"💔 Kecocokan Rendah. Ada perbedaan yang signifikan yang mungkin memerlukan banyak usaha dan kompromi untuk membuat hubungan ini berhasil.",r,u,k=(u=90<a?(r="Koneksi emosional yang kuat, pemahaman yang mendalam","Jaga komunikasi dan hindari rasa puas"):70<a?(r="Minat bersama, komunikasi yang baik","Hadapi konflik dengan kesabaran"):50<a?(r="Salah satu menghormati yang lain, siap untuk berunding","Kerja keras untuk menyelesaikan perbedaan secara konstruktif"):30<a?(r="Potensi untuk pertumbuhan, belajar satu sama lain","Fokus untuk meningkatkan komunikasi dan pemahaman"):(r="Menantang namun memuaskan jika dikerjakan dengan baik","Memerlukan usaha yang signifikan dalam komunikasi dan kompromi"),"Cupid Meter oleh "+global.botName),m=`Kepribadian *${h}:* ${e}
Kepribadian *${o}:* `+i,s=`💘 *C U P I D - M E T E R* 💘

`,g=(s=(s=(s=(s=(s+=`*Persentase Kecocokan*
`)+`👫 ${h} & ${o}

`+`❤️ *${a}%*

`)+`*Deskripsi:*
${t}

`+`*Kepribadian:*
${m}

`)+`*Kekuatan Hubungan:*
${r}

`)+`*Area untuk Ditingkatkan:*
${u}

`+`*Catatan:*
`+k,await d.sendMessage(l.chat,{text:"Menghitung kecocokan..."},{quoted:l,ephemeralExpiration:l.expiration}));setTimeout(async()=>{await d.sendMessage(l.chat,{text:s,edit:g.key},{quoted:l,ephemeralExpiration:l.expiration})},2e3)}catch(a){console.error("Error calculating compatibility: "+String(a)),await l.reply("Terjadi kesalahan saat menghitung kecocokan. Silakan coba lagi nanti.")}},limit:3};