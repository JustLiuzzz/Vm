// CREATE BY REZA DEVS KUROMI
function replacement(e) {
    return e.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
}
global.owner = "6283894064758@s.whatsapp.net", global.ownerName = "Reza", global.developer = ["6283894064758", "6283190004491"].map(replacement), global.botName = "KUROMI BOT", global.apikey = "API-4bipdh8h5f", global.fake = "", global.header = `KUROMI BOT v${require("./package.json").version} (Beta)`, global.footer = "ꜱɪᴍᴘʟᴇ ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ ᴍᴀᴅᴇ ʙʏ ʀᴇᴢᴀ", global.cooldown = 1, global.max_ram = 3, global.blocks = ["91", "92", "212"], global.prefixes = /^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.©^]/i, global.newsletter = "120363375725098747@newsletter", global.qrisUrl = "https://files.catbox.moe/dr0h9k.jpg", global.audioUrl = "https://cdn.filestackcontent.com/2r7cSUozTQ2tTS15NfFj", global.pairing = {
    copyFromLink: false,
    status: true,
    number: "+62 895-0242-3402",
    code: ""
}, global.config = {
    session: "session",
    online: true,
    version: [2, 3e3, 1015901307],
    browser: ["Windows", "Chrome", "20.0.04"],
    button: true
}, global.quoteApi = "https://qc.botcahx.eu.org/generate", global.mess = {
    wait: "Processed . . .",
    ok: "Successfully.",
    limit: "kamu telah mencapai limit harian dan akan di reset setiap jam 00.00\n- beli premium untuk mendapatkan unlimited limit.",
    premium: "yahh, kamu bukan user premium, beli premium dulu yuk",
    jadibot: "khusus user jadibot, ingin menjadikan bot trial ? ketik .jadibot-trial",
    owner: "This feature is only for owners.",
    devs: "This feature is only for developers.",
    group: "This feature will only work in groups.",
    private: "Use this feature in private chat.",
    admin: "This feature only for group admin.",
    botAdmin: "This feature will work when I become an admin",
    bot: "This feature can only be accessed by bots",
    wrong: "Wrong format!",
    error: {
        url: "URL is Invalid!",
        api: "Sorry an error occurred!"
    },
    block: {
        owner: "This feature is being blocked by owner!",
        system: "This feature is being blocked by system because an error occurred!"
    },
    query: "Enter search text",
    search: "Searching . . .",
    scrap: "Scrapping . . .",
    wrongFormat: "Incorrect format, please look at the menu again",
    game: "Bermain game di obrolan pribadi hanya untuk pengguna premium, tingkatkan ke paket premium hanya Rp. 20.000 selama 1 bulan."
}, require("./system/functions.js").reloadFile(__filename);